<div class="">

    <div id="fixedsocial" class="bg-gradien text-center">
        <a target="_blank" href="https://www.instagram.com/2v_tesis/?hl=es-la"><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-instagram.jpg')); ?>" alt=""></a>
        <a target="_blank" href="https://es-la.facebook.com/me.quiero.graduar.ya/"><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-facebook.jpg')); ?>" alt=""></a>
        
        <a class="whatsapp-mobile" target="_blank" href="https://api.whatsapp.com/send?phone=+593989558833"><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-whatsapp.jpg')); ?>" alt=""></a>

        <a class="whatsapp-web"target="_blank" href="https://web.whatsapp.com/send?phone=593989558833&text="><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-whatsapp.jpg')); ?>" alt=""></a>
    </div>
</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/front/layouts/fixedSocial.blade.php ENDPATH**/ ?>