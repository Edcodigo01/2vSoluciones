
<?php $__env->startSection("content"); ?>
    <div class="" id="scrollPaginate">

    </div>


    <div class="text-center paralax" style="background-image: url('public/images/contactenos/operadora.jpg');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">
            <span class="bg-green mt-3 px-3 py-2" style="display:inline-block">
                <h4 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-phone-alt"></i> Contáctanos</h4>
            </span>
        </div>

    </div>
    <div class="container2">
        <div class="row my-3">
            <div class="col-md-6 col-xl-3 mb-4">
                <div class="card bg-green text-white" style="height:100%">
                    <div class="card-body">
                        <h2 class="text-center text-white" style="font-size:60px"><i class="icon-placeholder"></i></h2>
                        <h4 class="text-center text-white">Dirección</h4>
                        <p class="text-white text-center" style="font-size:18px">Av. Mariana de Jesús y Jorge Juan N31-120, Quito - Ecuador</p>
                    </div>
                </div>
            </div>


            <div class="col-md-6 col-xl-3  mb-4">
                <a class="whatsapp-mobile" href="https://api.whatsapp.com/send?phone=+593989558833" class="whatsapp-mobile">
                    <div class="card bg-purple" style="height:100%">
                        <div class="card-body">
                            <h2 class="text-center text-white" style="font-size:60px"><i class="fab fa-whatsapp"></i></h2>
                            <h4 class="text-center text-white">Whatsapp</h4>
                            <p class="text-white text-center" style="font-size:14px">Has click aquí para abrir la aplicación de whatsapp, o agrega nuestro número: <span class="font600" style="font-size:16px">+593989558833</span></p>

                        </div>
                    </div>
                </a>
                <a class="whatsapp-web" href="https://web.whatsapp.com/send?phone=593989558833&text=" class="whatsapp-web">

                    <div class="card bg-purple" style="height:100%">
                        <div class="card-body">
                            <h2 class="text-center text-white" style="font-size:60px"><i class="fab fa-whatsapp"></i></h2>
                            <h4 class="text-center text-white">Whatsapp</h4>
                            <p class="text-white text-center" style="font-size:12px">Has click aquí para abrir la aplicación de whatsapp, o agrega nuestro número: <span class="font600" style="font-size:16px"><br> <img class="social-icon-contactenos" src="<?php echo e(asset('public\images\default\redes sociales\logo-whatsapp.jpg')); ?>" alt=""> +593989558833</span></p>

                        </div>
                    </div>
                </a>
            </div>


            <div class="col-md-6 col-xl-3  mb-4">
                <div class="card bg-green text-white" style="height:100%">
                    <div class="card-body">
                        <h2 class="text-center text-white" style="font-size:60px"><i class="fas fa-users"></i></h2>
                        <h4 class="text-center text-white">Redes Sociales</h4>
                        <div class=" text-center">
                            <a target="_blank" href="https://www.instagram.com/2v_tesis/?hl=es-la"><img class="social-icon-contactenos" src="<?php echo e(asset('public\images\default\redes sociales\logo-instagram.jpg')); ?>" alt=""></a>
                            <a target="_blank" href="https://es-la.facebook.com/me.quiero.graduar.ya/"><img class="social-icon-contactenos" src="<?php echo e(asset('public\images\default\redes sociales\logo-facebook.jpg')); ?>" alt=""></a>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xl-3  mb-4">
                    <div class="card bg-purple" style="height:100%">
                        <div class="card-body">
                            <h2 class="text-center text-white" style="font-size:60px"><i class="far fa-envelope"></i> </h2>
                            <h4 class="text-center text-white">Correo</h4>
                            <p class="text-white text-center mailContact"> tulogroesnuestroexito2v <br> @gmail.com</p>
                        </div>
                    </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card my-2">
                    <div class="card-header bg-gradient">
                        <h4 class="text-white"><i class="fas fa-paper-plane"></i> Realiza tu consulta ya:</h4>

                    </div>
                    <div class="card-body">

                        <form class="formula validate" action="<?php echo e(route('message-contact')); ?>" method="post" id="message-contact">
                        <div class="row">
                            <div class="form-group col-lg-6 col-sm-6 col-md-12">
                                <label for="">Tu Correo: <span class="text-danger">*</span></label>
                                <input type="email" name="email" value="" class=" form-control form-control-sm required email" maxlength="60">
                            </div>
                            <div class="form-group col-lg-6 col-sm-6 col-md-12">
                                <label for="">Teléfono :</label>
                                <input type="text" name="whatsapp" value="" class="form-control form-control-sm number onlyNumber" maxlength="16">
                            </div>
                            <div class="form-group col-12">
                                <label for="">Asunto:</label>
                                <input type="text" name="affair" value="" class="asunto form-control form-control-sm" maxlength="99" placeholder="Preguntar por los servicios de 2v Soluciones Académicas & Empresariales">
                            </div>
                            <div class="form-group col-12">
                                <label for="">Mensaje:<span class="text-danger">*</span></label>
                                <textarea name="message" rows="4" cols="20" class="form-control form-control-sm required" maxlength=450></textarea>

                            </div>
                            <div class="form-group text-center col-12">
                                <div class="g-recaptcha" data-sitekey="6LdjBLAZAAAAANjl-8JYDdiFCQC_oSJb0p-Dnj42" data-callback="enableBtn" style="transform:scale(0.8);transform-origin:0;-webkit-transform:scale(0.8);transform:scale(0.8);-webkit-transform-origin:0 0;transform-origin:0 0;"></div>
                            </div>
                        </div>

                        <button type="submit" name="button" class="btn bg-purple text-white ml-2 float-right btn-lg" id="btnFormContact" >Enviar</button>
                        <button type="button" name="button" class="btn bg-green float-right btn-lg" onclick="vaciarForm();$('#btnFormContact').attr('disabled',true);grecaptcha.reset()">Cancelar</button>
                        </form>
                    </div>
                </div>

            </div>
            <div class="col-md-6">

                    <div class="card my-2">
                        <div class="card-header bg-gradient">
                            <h4 class="text-white"> <i class="fas fa-maps"></i> Nuestra ubicación</h4>

                        </div>
                        <div class="card-body">

                            <div class="iframe-maps">
                                <iframe  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18978.7678549331!2d-78.50730632741512!3d-0.19813681025510507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x91d59b18e7a9d205%3A0x1af99cd88d9c0e29!2s2V%20Soluciones%20Acad%C3%A9micas%20%26%20Empresariales!5e0!3m2!1ses!2sec!4v1590257178607!5m2!1ses!2sec"  frameborder="0" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                            </div>

                        </div>
                    </div>


            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    function vaciarForm(){
        form = $('#message-contact');
        $(form).find('.form-control').each(function() {
            $(this).val('');
        });
        (form).find('.asunto').val('');
        $(form).data('validator').resetForm();
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/contactenos.blade.php ENDPATH**/ ?>