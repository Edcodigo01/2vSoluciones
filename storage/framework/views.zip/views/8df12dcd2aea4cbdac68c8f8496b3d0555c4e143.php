
<?php $__env->startSection('title'); ?>
  2V-Admin-Servicios
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <h2 class="mb-4 text-green">Servicios</h2>

    <table class="listar table table-bordered table-striped listar" data-route="list_adminservices" data-update="administrar-servicios/{id}" data-delete="administrar-servicios/{id}" id="table-services">

    <thead>
      <tr>
        <th>Id</th>
        <th>Acciones:</th>
        <th>Nombre</th>
        <th>Precio</th>
      </tr>
    </thead>
    <tbody>

    </tbody>
    </table>

    <?php echo $__env->make('services.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('services.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input type="hidden" name="" value="<?php echo e($dataServices); ?>" id="data">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/services/services.blade.php ENDPATH**/ ?>