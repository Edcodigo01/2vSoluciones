<?php if($videos->first()): ?>
    <br>
    <br>
    <?php if(request()->video): ?>
       <input type="hidden" name="" value="<?php echo e($videoSelect = $videos->where('slug',request()->video)->first()); ?>" >

    <?php else: ?>
       <input type="hidden" name="" value="<?php echo e($videoSelect = $videos->first()); ?>" >
    <?php endif; ?>

    <div class="container2 videos">

       
          <div class="containIframe">
          <?php if(request()->video == Null): ?>
              <iframe style="" src="<?php echo e('https://www.youtube.com/embed/'.$videos->first()->url); ?>" id="videoYoutube" allowfullscreen = "allowfullscreen"></iframe>
           <?php else: ?>
              <iframe style="" src="<?php echo e('https://www.youtube.com/embed/'.$videoSelect->url); ?>" id="videoYoutube" allowfullscreen = "allowfullscreen"></iframe>
           <?php endif; ?>
          </div>

       <h6 id="titleVideo" class="text-center text-green-l"><?php if($videoSelect): ?> <?php echo e($videoSelect->title); ?> <?php endif; ?></h6>
       <?php if($videoSelect and $videoSelect->description): ?>
          <h6 class="">Descripción</h6>
          <p class=""><?php echo e($videoSelect->description); ?></p>
       <?php endif; ?>
    
    <div class="viewAjaxOnlyVideos" data-route="<?php echo e(url('lista-videos-busqueda')); ?>">
       <?php echo $__env->make('front.videos.videosSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



    <input type="hidden" name="" value="<?php echo e($videos->currentPage()); ?>" class="form-control" id="pageNow">
    <input type="hidden" name="" value="<?php echo e(request()->video); ?>" class="form-control" id="search-video">



    </div>
    <br>
    <br>
<?php else: ?>
    <div class="alert alert-info mt-5" style="width: 100%;max-width:800px;margin:auto">
       <h5 class="text-center mt-2"><i class="fas fa-exclamation-triangle"></i> No ahí videos registrados</h5>
    </div>
<?php endif; ?>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/front/videos/videos_ajax.blade.php ENDPATH**/ ?>