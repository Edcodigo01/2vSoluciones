
<?php $__env->startSection('title'); ?>
    2V-inicio-session-Administración
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="bg-" style="display:flex;justify-content:center;background:rgba(191, 111, 144, 0.13)">


        <div class="card my-4" style="width:350px !important">
            <div class="card-header">
                <img src="<?php echo e(asset('public/images/default/logo.jpg')); ?>" alt="" style="width:100px;margin:auto;display: block" class="text-center">

                    <h5 class="text-center text-purple">Iniciar Sessión</h5>
                    <h6 class="text-center text-purple">Panel Administración</h6>
                    <form class="formula validate" action="<?php echo e(route('login')); ?>" method="post" id="form-login">
                        <div class="form-group">
                            <label for=""><i class="fas fa-envelope"></i> Email</label>
                            <input type="text" name="email" value="" class="form-control required">
                        </div>
                        <div class="form-group">
                            <label for=""><i class="fas fa-envelope"></i> Contraseña</label>
                            <input type="password" name="password" value="" class="form-control required password" id="blockMayus">
                        </div>
                        <div class="form-group">
                            <button type="submit" name="button" class="btn bg-purple btn-block">Iniciar Sesión</button>
                            <button type="button" name="button" class="btn bg-green btn-block text-white">Cancelar</button>

                        </div>
                    </form>

            </div>

        </div>




    </div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/admin/AdminIni.blade.php ENDPATH**/ ?>