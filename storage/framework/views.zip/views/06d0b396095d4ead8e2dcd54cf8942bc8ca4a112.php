<?php $__env->startSection("content"); ?>

    
    <div class="text-center paralax" style="background-image: url('public/images/default/libros.jpg');background-position:bottom">
        <div class="container-title" style="background:rgba(36, 35, 35, 0.38)">
            <span class="bg- px-3 py-2" style="display:inline-block">
                <h2 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-book-open"></i> Artículos</h2>
            </span>
        </div>
    </div>

    <?php echo $__env->make('front.articles.filtersMobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container2 mt-4">
        
        <div class="row m-auto" style="width:100%">
            <div class="col-12 p-0">
                <button type="button" name="button" class="btn btn-purple btn-sm m-0 mb-1 float-right btnFiltersMobile"><i class="fas fa-search"></i> Buscar</button>
            </div>
        </div>
        <div class="row m-auto" style="width:100%">

            <div class="col-lg-8 col-xl-9 mb-4 px-0">
                <div class="card">
                    <div class="card-body">
                       
                        <?php if(request()->titulo != null and request()->titulo != 'Todas'): ?>
                        <h6 style="display:" class="showSearch">Título: <span class="text-secondary textShowSearch"><?php echo e(request()->titulo); ?></span></h6>

                        <?php endif; ?>
                        <div class="form-inline mb-3">
                            <?php if(request()->categoria != null and request()->categoria != 'Todas'): ?>
                                <h6 style="display:" class="showCategory">Categoría: <span class="textShowCategory text-secondary"><?php echo e(request()->categoria); ?></span></h6>
                            <?php else: ?>
                                <h6 style="display:none" class="showCategory">Categoría: <span class="textShowCategory text-secondary"></span></h6>
                            <?php endif; ?>

                            <?php if(request()->tag != null and request()->tag != 'Todas'): ?>
                                <h5 style="display:" class="ml-5 showTag">Tag: <span class="textShowTag text-secondary"><?php echo e(request()->tag); ?></span></h5>
                            <?php else: ?>
                                <h5 style="display:none" class="ml-5 showTag">Tag: <span class="textShowTag text-secondary"></span></h5>
                            <?php endif; ?>
                        </div>

                            <div class="row articlesList m-auto" style="width:100%">
                                <?php if($articles->first() == null): ?>
                                    <div class="col-12">
                                        <h6 class="text-center text-purple"><i class="fas fa-exclamation-circle"></i> No se encontraron resultados</h6>
                                    </div>
                                <?php else: ?>
                                   <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-1 px-1">
                                           <a href="<?php echo e(route('article',$article->id)); ?>">
                                           <div class="card cardArticle show-title-complete" style="height:100%;">
                                               <div class="card-header p-1 border-g">
                                                   <img style="" class="" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                                               </div>
                                               <div class="card-body border-g">

                                                      <div class=" d-flex justify-content-center align-items-center">
                                                         <p style=" white-space: nowrap;text-overflow: ellipsis;overflow: hidden;" class="title-cut text-center text-dark font600"><?php echo e($article->title); ?></p>
                                                         <p class="text-center text-dark font600 title-complete hiden"><?php echo e($article->title); ?></p>
                                                      </div>

                                                   <p class="text-dark" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></p>

                                                   <button type="button" name="button" class="btn btn-sm btn-purple float-right">Leer</button>
                                                   <p class="float-left text-dark mt-2 date" style=""><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></p>
                                                   
                                               </div>
                                           </div>
                                           </a>
                                       </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>


                    </div>
                    <div class="card-footer text-green bg-white">
                        Página nro <?php echo e($articles->currentPage()); ?> de
                        <input type="hidden" name="" value="<?php echo e($articles->currentPage()); ?>" class="form-control" id="numberPage">
                        <?php echo e($articles->lastPage()); ?>

                        <span class="pagination float-right"><?php echo e($articles->links()); ?></span>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 col-xl-3 px-1 filtersLG">
                <div class="card">
                    <div class="card-body">
                       <h6 class="text-green-l"> Filtros</h6>
                       <form  class="" action="<?php echo e(url('articulos')); ?>" method="get" id="formSearchPost">

                          <div class="row m-auto" style="width:100%">
                             <div class="col-12 col-md-4 col-lg-12">
                                 <label for="">Título del artículo</label>
                                 <input type="text" name="titulo" value="<?php echo e(request()->titulo); ?>" class="form-control form-control-sm">
                             </div>
                             <div class="col-12">
                                 <?php if($categories->first() != Null): ?>
                                     <label for="">Categoría</label>
                                     <select class="form-control form-control-sm" name="categoria" >
                                         <?php if(request()->categoria == Null): ?>
                                             <option value="" selected class="">Todas</option>
                                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option  value="<?php echo e($value->name); ?>" class=""><?php echo e($value->name); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php else: ?>

                                             <option value="" class="">Todas</option>
                                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <?php if(request()->categoria == $value->name): ?>

                                                     <option class="" value="<?php echo e($value->name); ?>" selected><?php echo e($value->name); ?></option>
                                                 <?php else: ?>
                                                     <option class="" value="<?php echo e($value->name); ?>" ><?php echo e($value->name); ?></option>
                                                 <?php endif; ?>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                         <?php endif; ?>
                                     </select>

                                 <?php endif; ?>
                             </div>
                         <div class="col-12">
                            <?php if(request()->titulo or request()->categoria): ?>
                               <a href="<?php echo e(url('articulos')); ?>" type="button" name="button" class="ml-1 btn btn-purple text-white mt-2 float-right" style=""><i class="fas fa-backspace"></i> </a>
                            <?php endif; ?>

                             <button  type="submit" name="button" class="btn btn-purple mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                         </div>
                         </div>
                       </form>
                    </div>

                </div>

                <?php if($categories->first() != Null): ?>
                    <div class="card mt-4">
                        <div class="card-body">
                           <h6 class="text-green-l"> Categorías</h6>
                           <input type="hidden" name="" value="<?php echo e($number = 0); ?>">
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <input type="hidden" name="hidden" value="<?php echo e($number = $number + 1); ?>" >
                              <hr style="margin:0px;padding:0px">

                              <div class="searchCategory" data-val="<?php echo e($category->name); ?>">
                                   <span class="font600"><?php echo e($category->name); ?> </span><span class="bg-green-l float-right text-center" style="border-radius:20px;width:20px"><?php echo e($category->articles->where('disabled','no')->count()); ?></span>
                              </div>
                              <hr style="margin:0px;padding:0px">
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div class="searchCategory" id="todos" data-val="">
                              <span class="font600">Todas </span><span class="bg-green-l float-right text-center" style="border-radius:20px;width:20px"><?php echo e($articlesCount)); ?></span> 
                           </div>

                        </div>
                    </div>
                <?php endif; ?>


            </div>
            <br>
            <br>


        </div>


    </div>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    $(document).on('submit','#formSearchPost', function(e){
      e.preventDefault();
      titulo = $(this).find('input[name="titulo"]').val();
      category = $(this).find('select[name="categoria"]').val();
      if (titulo.length != 0) {
         titulo = 'titulo='+titulo;
      }else{
         titulo = '';
      }
      if (category.length != 0) {
         category = 'categoria='+category;
      }else{
         category = '';
      }

      if (category.length != 0 && titulo.length != 0) {
         $and = '&';
      }else{
         $and = '';
      }
      if (category.length != 0 || titulo.length != 0) {

         $interrogation = '?';
      }else{


         $interrogation = '';
      }
      window.location.href = '<?php echo e(url('articulos')); ?>'+$interrogation+category+$and+titulo;
    });


    $(document).on('click','.searchCategory', function(e){

      category = $(this).attr('data-val');
      if (category.length != 0 && category != '') {
         category = '?categoria='+category;
      }else{
         category = '';
      }

      window.location.href = '<?php echo e(url('articulos')); ?>'+category;

    });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("front.layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/front/articles/articles.blade.php ENDPATH**/ ?>