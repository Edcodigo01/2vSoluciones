
<?php $__env->startSection("content"); ?>

    <div class="text-center paralax" style="background-image: url('public/images/default/home/manosOk.jpg');background-position:bottom">
        <div class="container-title" style="background:rgba(36, 35, 35, 0.38)">
            <span class=" px-3 py-2" style="display:inline-block">
                <h2 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-comments"></i> Testimonios</h2>
            </span>
        </div>
    </div>

    
   <div class="-l" style="">
      <br>
      <div class="container2 ">
        
        <h6 class="text-dark text-center mt-2">Por favor déjanos saber tu opinión acerca de nosotros.</h6>
        <br>
        <div class="card" style="">
            <div class="card-body pt-0" >
               <h6 class="text-center text-purple mt-5" id="messageLoadComment"><img src="<?php echo e(asset('public/images/default/loader/spinner.gif')); ?>" alt="" style="width:40px;height:40px"> Cargando comentarios desde "Facebook" por favor espere.</h6>
               <div style="width:100%" class="fb-comments containerScroll" data-href="https://2vsoluciones.com/2v/" data-numposts="6" width="100%" data-width="100%" data-order-by="times"></div>
            </div>
        </div>
        <br>
        <p class="text-center" style="max-width:1000px;margin:auto">Más comentarios en nuestra cuenta de Facebook.</p>

        <div class="text-center mt-2">
            <a target="_blank" href="https://business.facebook.com/me.quiero.graduar.ya/?business_id=301312427099496"><img src="<?php echo e(asset('public\images\default\redes sociales\logo-facebook.jpg')); ?>" alt="" style="border-radius:12px;max-width:50px;border:solid 2px white"></a>
            
        </div>

     </div>
     <br>
     <br>

   </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v7.0&appId=201064434390930&autoLogAppEvents=1" nonce="EAUQffoA"></script>

   <script>
   window.fbAsyncInit = function(){
      FB.Event.subscribe("xfbml.render", function(){
           $('#messageLoadComment').hide();
      });
   };
   </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("front.layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/front/testimonios.blade.php ENDPATH**/ ?>