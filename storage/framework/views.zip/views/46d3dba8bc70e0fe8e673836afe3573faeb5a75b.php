<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="<?php echo e(route('home')); ?>" class="brand-link text">
    <img src="<?php echo e(asset('public/images/default/logos/logo-t.png')); ?>"
         alt="AdminLTE Logo"
         class="brand-image img-circle elevation-3"
         style="opacity: .8">
    <span class="brand-text" style="font-size:17px">2v S. Academicas</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user (optional) -->
        
            
          
        

    <!-- Sidebar Menu -->

    <nav class="mt-2">

      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
             <li class="nav-item">

               <a href="<?php echo e(route('admin')); ?>" class="nav-link <?php if(Request::route()->getName() == 'admin'): ?> active <?php endif; ?>">
                <i class="fas fa-cogs nav-icon"></i>
                 <p>
                    Panel de Administración
                 </p>
               </a>
             </li>
             <li style="border-bottom:solid 1px grey" class=""></li>

         <li class="nav-item">
           <a href="<?php echo e(route('administrar-articulos.index')); ?>" class="nav-link <?php if(Request::route()->getName() == 'administrar-articulos.index'): ?> active <?php endif; ?>">
            <i class="far fa-newspaper nav-icon"></i>
             <p>
               Artículos
             </p>
           </a>
         </li>
         <li class="nav-item">
           <a href="<?php echo e(route('administrar-categorias.index')); ?>" class="nav-link <?php if(Request::route()->getName() == 'administrar-categorias.index'): ?> active <?php endif; ?>">
             <i class="nav-icon fas fa-list-alt"></i> <p>Categorías</p>
           </a>
         </li>
         <li class="nav-item">
           <a href="<?php echo e(route('administrar-etiquetas.index')); ?>" class="nav-link  <?php if(Request::route()->getName() == 'administrar-etiquetas.index'): ?> active <?php endif; ?>">
             <i class="nav-icon fas fa-tag"></i>
             <p>
               Etiquetas
             </p>
           </a>
         </li>
         <li style="border-bottom:solid 1px grey" class=""></li>
        

        

        <li class="nav-item">
          <a href="<?php echo e(route('administrar-videos.index')); ?>" class="nav-link <?php if(Request::route()->getName() == 'administrar-videos.index'): ?> active <?php endif; ?>">
            <i class="nav-icon fab fa-youtube"></i>
            <p>
              Videos
            </p>
          </a>
        </li>
         <li style="border-bottom:solid 1px grey" class=""></li>
        <li class="nav-item">
          <a href="<?php echo e(route('mensajes-email.index')); ?>" class="nav-link <?php if(Request::route()->getName() == 'mensajes-email.index'): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-envelope"></i>
            <p>
              Emails Recibidos
            </p>
          </a>
        </li>

        


      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/layoutsAdmin/aside.blade.php ENDPATH**/ ?>