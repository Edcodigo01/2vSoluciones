<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="modalCreate">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h4 class="text-white"><i class="fas fa-list"></i> Agregar artículo</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" data-toggle="tooltip" data-placement="top" title="Minimizar">
            <span aria-hidden="true"><i class="fas fa-minus"></i></span>
        </button>

      </div>
       <form class="form-file validateH" action="<?php echo e(route('administrar-articulos.store')); ?>" method="post" id="create">
      <div class="modal-body">

              <div class="row">

                  <div class="col-md-6 form-group">
                      <label for="">título</label>
                      <input type="text" name="title" value="" class="form-control required">
                  </div>
                  <div class="col-md-3 form-group">
                      <label for="">Autor</label>
                      <input type="text" name="autor" value="" class="form-control required autorCreate noVaciar">
                  </div>
                  
                  <div class="col-md-3 form-group">
                      <label for="">Categoría</label>

                          <select class="form-control published select required" name="category_id">
                              <option selected="selected" value="">Seleccione una Opción</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>

                  </div>


                  
                  <div class="col-12 form-group">
                      <label for="">Contenido</label>
                      <textarea name="content" rows="4" cols="40" class="form-control ckedit" id="contentCreate"></textarea>
                  </div>

                  <div class="col-2 text-center">
                      <label for="">Imagen <span class="text-danger">*</span></label>
                      <div class="contentInputImg" style="max-width:300px;max-height:200px">
                          <div class="mb-1">
                              <img src="<?php echo e(asset('public\images\default\image-default.jpg')); ?>" class="imagePreviewInput" width="100%;" style="height:100px;object-fit:contain">
                          </div>
                          <div class="updateDeleteImage" style="display:none">
                              <button type="button" name="button" class="btn btn-success btn-file btn-block"><i class="fas fa-sync-alt mr-1"></i>Cambiar</button>
                          </div>
                          <button type="button" name="button" class="btn btn-primary btn-file btn-block btn-up"><i class="fas fa-upload mr-1"></i>Subir Imagen</button>
                          <input type="file" name="imageP" class="inputFile required imageP form-control" style="display:none">
                      </div>
                  </div>
                  
              </div>
      </div>
      <div class="modal-footer">
        <button type="button" class=" btn btn-secondary " name="button" onclick="cancelModal('#modalCreate','#create');">Cancelar</button>
        <button type="sumbmit" class="btn btn-primary  mr-2" name="button">Guardar</button>
      </div>
    </form>
    </div>
  </div>
</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/articles/includes/modalCreate.blade.php ENDPATH**/ ?>