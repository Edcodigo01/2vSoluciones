<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?php echo e(asset('public\libraries\adminLTE\css\adminlte.min.css')); ?>">

  <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <link rel="stylesheet" href="<?php echo e(asset('public\libraries\js\select2\css\select2.css')); ?>">

</head>
<body class="hold-transition sidebar-mini sidebar-collapse sidebar-closed layout-navbar-fixed layout-fixed">

    <?php echo $__env->make("layouts.loader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Site wrapper -->
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light bg-gradient font600" style="padding:8px;font-size:16px;color:white">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link text-white" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('home')); ?>" class="nav-link text-white">Inicio</a>
      </li>

      <li class="dropdown nav-item d-none d-sm-inline-block">
        <a class="btn btn-outline-light ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'servicios')): ?> active <?php endif; ?>">   Servicios <i class="fa fa-chevron-down"></i></a>
        <div class="dropdown-content bg-secondary">

            <a class="dropdown-item text-white font600" href="<?php echo e(url('servicios-academicos')); ?>"><i class="fas fa-university"></i> Académicos</a>
            <a class="dropdown-item text-white font600" href="<?php echo e(url('servicios-empresariales')); ?>"><i class="fas fa-user-tie"></i> Empresariales</a>
        </div>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('articles')); ?>" class="nav-link text-white">Artículos de Interes</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('somos')); ?>" class="nav-link text-white">Quienes Somos</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('videos')); ?>" class="nav-link text-white">Videos</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('contactanos')); ?>" class="nav-link text-white">Contáctanos</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

        <?php if(Auth::check()): ?>
            <li class="dropdown">
              <button class="nav-link  text-white btn"> <i class="fa fa-user"></i> <?php echo e(Auth::user()->email); ?> <i class="fa fa-chevron-down"></i></button>
              <div class="dropdown-content" style="margin-left:-50px">

                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt"></i> Cerrar Sessión</a>
              </div>
            </li>

        <?php endif; ?>
      
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->

  <?php echo $__env->make('layoutsAdmin.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper bg-white">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content ">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12 mt-2 mb-5">
              <div class="container2">
            <?php echo $__env->yieldContent('content'); ?>

              </div>
          </div>
        </div>

      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('public\libraries\ckeditor4-standar-custom\ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('public\libraries\js\select2\js\select2.full.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>





</body>
</html>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/layoutsAdmin/index.blade.php ENDPATH**/ ?>