
  <!-- ##### All Javascript Script ##### -->
  <!-- jQuery-2.2.4 js -->
  <script src="<?php echo e(asset("public/libraries/js/jquery/jquery-2.2.4.min.js")); ?>"></script>
  <!-- Popper js -->
  <script src="<?php echo e(asset("public/libraries/js/bootstrap/popper.min.js")); ?>"></script>
  <!-- Bootstrap js -->
  <script src="<?php echo e(asset("public/libraries/js/bootstrap/bootstrap.min.js")); ?>"></script>
  <script src="<?php echo e(asset('public\libraries\fontawesome\js\fontawesome.min.js')); ?>"></script>
  <!-- All Plugins js -->

  <script src="<?php echo e(asset("public\libraries\adminLTE\js\adminlte.min.js")); ?>"></script>

  <script src="<?php echo e(asset("public/libraries/js/plugins/plugins.js")); ?>"></script>
  <!-- Active js -->
  <script src="<?php echo e(asset("public/libraries/js/active.js")); ?>"></script>

  <script src="<?php echo e(asset('public\libraries\jquery.validate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/validaciones-jquery.js')); ?>"></script>


<script src="<?php echo e(asset('public\libraries\DataTables\datatables.min.js')); ?>"></script>

<script src="<?php echo e(asset('public\libraries\DataTables\DataTables-1.10.20\js\dataTables.bootstrap4.min.js
')); ?>"></script>



  <script src="<?php echo e(asset('public\libraries\toastr\toastr.js')); ?>"></script>
  <script src="<?php echo e(asset('public\libraries\venobox\venobox.min.js')); ?>"></script>


  
  <script src="<?php echo e(asset("public/js/tables.js")); ?>"></script>
  <script src="<?php echo e(asset("public/js/table_no_ajax.js")); ?>"></script>


<script src="<?php echo e(asset("public\js\animations.js")); ?>"></script>

<script src="<?php echo e(asset("public/js/forms.js")); ?>"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script src="<?php echo e(asset("public/js/modal.js")); ?>"></script>
<script src="<?php echo e(asset("public/js/project.js")); ?>"></script>
<script src="<?php echo e(asset("public/js/inputs.js")); ?>"></script>
<script src="<?php echo e(asset("public/js/videos.js")); ?>"></script>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>