
<?php $__env->startSection('title'); ?>
  2V-Admin-Clientes
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>


    <h2 class="mb-4 text-green">Clientes</h2>


    <div id="bgObscure" style="display:none">
    </div>

    <table style="width:100%" class="listar table table-bordered table-striped listar" data-route="list_clients" data-update="clientes/{id}" data-updateService="servicios-de-proyecto/{id}" data-routeAdd="iniciar-proyecto/{id}"  id="table-clients">

    <thead>
      <tr>
        <th>Id</th>
        <th>Acciones:</th>
        <th>Nombre Completo</th>
        <th>Correo</th>
        
        <th>Nro Id</th>
        <th>ult. Proyectos</th>
        <th>Nro whatsapp</th>
        
        
        
        
      </tr>
    </thead>
    <tbody>

    </tbody>
    </table>

    <?php echo $__env->make('clients.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.modalAdd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.modalAddService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.modalEditService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.modalDeleteService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.all_project_client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('clients.includes.modalEditProject', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    
    <input type="hidden" name="" value="<?php echo e($dataClients); ?>" id="data">
    
    <input type="hidden" name="" value="<?php echo e($services); ?>" id="servicesArray">
    



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/clients/clients.blade.php ENDPATH**/ ?>