
<?php /**PATH C:\xampp\htdocs\2v\resources\views/layoutsAdmin/modalsGlobal/modalDelete.blade.php ENDPATH**/ ?>