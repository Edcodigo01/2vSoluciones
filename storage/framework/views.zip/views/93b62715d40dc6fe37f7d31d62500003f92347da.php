
  <!-- ##### All Javascript Script ##### -->
  <!-- jQuery-2.2.4 js -->
  <script src="<?php echo e(asset("public/libraries/js/jquery/jquery-2.2.4.min.js")); ?>"></script>
  <!-- Popper js -->

  <script src="<?php echo e(asset("public/libraries/popper.js")); ?>"></script>
  <!-- Bootstrap js -->
  <script src="<?php echo e(asset("public/libraries/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>
  <script src="<?php echo e(asset('public/libraries/fontawesome/js/fontawesome.min.js')); ?>"></script>
  <!-- All Plugins js -->

  

  
  <!-- Active js -->
  

  <script src="<?php echo e(asset('public/libraries/jquery.validate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/validaciones-jquery.js')); ?>"></script>








  <script src="<?php echo e(asset('public/libraries/toastr/toastr.js')); ?>"></script>
  <script src="<?php echo e(asset('public/libraries/venobox/venobox.min.js')); ?>"></script>


  
  
  


<script src="<?php echo e(asset("public/js/animations.js")); ?>"></script>

<script src="<?php echo e(asset("public/js/forms.js")); ?>"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>





<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/front/layouts/scripts.blade.php ENDPATH**/ ?>