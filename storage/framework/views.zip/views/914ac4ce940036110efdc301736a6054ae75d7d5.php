
<?php $__env->startSection("content"); ?>



    <div class="" id="scrollPaginate">

    </div>
    <div class="text-center paralax" style="background-image: url('public/images/default/somos/somos.jpg');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">

            <span class="bg-green px-3 py-2" style="display:inline-block">
                <h4 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-users"></i> Quiénes Somos</h4>
            </span>

        </div>

    </div>


    <div class="container2">

        <div class="row my-5">
            <div class="col-12 wow fadeInUp">
                <div class="">
                    <h2 style="text-align:center !important">Identidad </h2>

                </div>
                <div class="text-justify">
                    <p class="" style="font-size:18px">Equipo de trabajo multidisciplinario dedicado a la asesoría a estudiantes en todos los niveles y modalidades de estudios, así como la asesoría a emprendedores en la materialización de sus proyectos de negocios.</p>
                </div>
            </div>

        </div>

        <div class="row mb-5">
            <div class="col-md-6 wow fadeInUp mb-4">

                <img src="<?php echo e(asset('public/images/default/somos/mision.jpg')); ?>" alt="" width="100%" style="height:300px;object-fit:cover;border-radius:5px">
            </div>
            <div class="col-md-6 wow fadeInLeft">
                <h3 class="">Misión</h3>
                <p class="text-justify" style="font-size:18px">Brindar a nuestros clientes un servicio con altos estándares de calidad, para que logren sus objetivos académicos y empresariales; alcanzando la excelencia.</p>
            </div>
        </div>

        <div class="row my-5">
            <div class="col-md-6 wow fadeInRight">
                <h3 class="">Visión</h3>
                <p class="text-justify" style="font-size:18px">Ser reconocidos como una empresa proveedora del servicio de asesoría académica y empresarial, caracterizada por su calidad, ética y compromiso.</p>
            </div>
            <div class="col-md-6 wow fadeInUp">

                <img src="<?php echo e(asset('public/images/default/somos/escribiendo.jpg')); ?>" alt="" width="100%" style="height:300px;object-fit:cover;border-radius:5px">
            </div>

        </div>


        <div class="row">
            <div class="col-12 wow fadeInUp">
                <div class="ml-5 mr-5">
                    <h2 style="text-align:center !important">Filosofía de Trabajo </h2>

                </div>
                <div class=" text-justify">
                    <p class="text-center" style="font-size:18px">Garantizar la satisfacción de nuestra distinguida clientela para que sea nuestra mejor carta de presentación.</p>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-12 wow fadeInUp">
                <div class="">
                    <h2 style="text-align:center !important">Historia</h2>

                </div>
                <div class="     text-justify">
                    <p class="" style="font-size:18px">Constituida inicialmente como Vargas – Vergara & Asociados y, para los efectos comerciales 2V: Soluciones Académicas & Empresariales, inició sus operaciones formalmente durante el mes de septiembre de 2017.
                        Desde entonces, por iniciativa de sus fundadoras: Lcda. Adriana Vargas y Lcda. Anggi Vergara, esta institución con sede en la ciudad de Quito – Ecuador, ha prestado de forma ininterrumpida, servicios de asesoría para aspirantes a graduando en todos los niveles y modalidades de estudio, así como a emprendedores en la materialización de sus proyectos de negocio.
                    </p>
                </div>
            </div>

        </div>
    </div>



    <div class="paralax contacto py-5 text-center">
        <div class="container2">
            <img src="<?php echo e(asset('public\images\default\logo.jpg')); ?>" alt="" style="width:300px;margin:auto">
            <h1 class="text-center text-purple wow fadeInUp mt-2"><span style="">¡Tu logro es nuestro éxito!</span></h1>
        </div>
    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/somos.blade.php ENDPATH**/ ?>