<div class="row mb-2 mt-3">
    <div class="col-12">

      <div class="card float-right cardSVideo" style="">
           <div class="card-body p-3 ">
               <form class="formula" action="<?php echo e(url('lista-videos-busqueda')); ?>" method="get" id="formVideos">
                  <label class="" for="">Buscar video</label>
                  <div class="input-group">
                     <input name="search" value="<?php echo e(request()->search); ?>" required type="text" class="form-control form-control-sm required" placeholder="" aria-label="" aria-describedby="basic-addon2">
                     <div class="input-group-append">
                        
                       <button class="btn btn-sm btn-purple" type="submit"><i class="fas fa-search"></i> </button>
                     </div>
                   </div>
               </form>
               <?php if(request()->search): ?>

                  <button type="button" name="button" class="btn bg-green btn-sm mt-4 btn-block" onclick="viewAjax('.viewAjaxOnlyVideos')">Mostrar todos los videos</button>
               <?php endif; ?>

           </div>
      </div>

    </div>
</div>

<?php if($videos->first() == null): ?>
   <h5 class="text-warning text-center mt-5"><span class="text-" style="font-size:30px"><i class="fas fa-exclamation-triangle"></i></span> No se encontraron resultados</h5>
<?php else: ?>

   <h5 style="display:none" class="showSearch">Busqueda: <span class="text-secondary textShowSearch"></span></h5>
       <div class="row px-3">
          <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             <div class="col-xl-3 col-lg-4 col-md-4 col-6 mb-1 px-1">

                 <div class=" card relative playVideo <?php if($videoSelect and $videoSelect->id == $video->id): ?> select <?php endif; ?>" data-url="<?php echo e($video->url); ?>" data-description="<?php echo e($video->description); ?>" style="height:100%" data-title="<?php echo e($video->title); ?>" data-slug="<?php echo e($video->slug); ?>">

                     <div class="card-header  p-2" style="height:50px;overflow:hidden; display: flex;align-items: center;justify-content: center;">
                         <p class="m-0  text-center text- " style="line-height:1"><?php echo $video->title; ?> </p>
                     </div>
                     <div class="card-body p-0 bg-green" style="position: relative">

                         <div class="logo-play" style="">
                             <i class="fab fa-youtube"></i>
                         </div>

                         <img src="<?php echo e('https://img.youtube.com/vi/'.$video->url.'/0.jpg'); ?>" alt="" style="width:100%;height:100%;object-fit: cover;">
                     </div>
                 </div>
             </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       <?php if($videos->lastPage() != 1): ?>
          <br>
                  <span class="pagination float-right"><?php echo e($videos->links()); ?></span>

                   <p class="">Página Nro. <?php echo e($videos->currentPage()); ?> de
                      <?php echo e($videos->lastPage()); ?></p>

            <?php endif; ?>
       <?php endif; ?>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/front/videos/videosSearch.blade.php ENDPATH**/ ?>