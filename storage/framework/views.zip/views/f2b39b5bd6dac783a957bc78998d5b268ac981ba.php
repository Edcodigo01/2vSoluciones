
<?php $__env->startSection("content"); ?>

    

    <div class="text-center paralax" style="background-image: url('public/images/default/libros.jpg');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">

            <span class="bg-green px-3 py-2" style="display:inline-block">
                <h3 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-book-open"></i> Artículos</h3>
            </span>


        </div>

    </div>

    <div class="" id="scrollPaginate">

    </div>
    <div class="container2 mt-4">
        
        <div class="row">

            
            <div class="col-12 maxMdShow mb-2">
                <div class="card">
                    <div class="card-header bg-gradient">
                        <h5 class="text-white"><i class="fas fa-filter"></i> Filtros Articulos</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6 col-md-4 col-lg-12">
                                <label for="">Nombre</label>
                                <input type="text" name="" value="" class="form-control form-control-sm filterSearch">
                            </div>
                            <div class="col-6 col-md-4">
                                <?php if($categories->first() != Null): ?>
                                    <label for="">Categoríayy</label>
                                    <select class="form-control form-control-sm filterCategory" name="">
                                        <?php if(request()->categoria == Null): ?>
                                            <option value="" selected>Todas</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <?php else: ?>

                                            <option value="">Todas</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(request()->categoria == $value->name): ?>

                                                    <option  value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    </select>

                                <?php endif; ?>
                            </div>
                            <div class="col-6 col-md-4">
                                <?php if($tags->first() != Null): ?>
                                    <label for="">Etiqueta</label>
                                    <select class="form-control form-control-sm filterTag" name="">
                                        <option value="" selected>Todas</option>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value=""></option>
                                    </select>
                                <?php endif; ?>
                            </div>
                        </div>

                        <button type="button" name="button" class="deleteSearch ml-1 btn bg-purple text-white mt-2 float-right" style="display:none"><i class="fas fa-backspace"></i> </button>
                        <button type="button" name="button" class="searchArticles btn bg-green mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-9 mb-4" id="viewAjax">
                <div class="card">
                    <div class="card-header bg-gradient">
                        <h4 class="text-center text-white">Artículos </h4>
                    </div>
                    <div class="card-body">

                        <?php if(request()->busqueda != null and request()->busqueda != 'Todas'): ?>
                        <h5 style="display:none" class="showSearch">Busqueda: <span class="text-secondary textShowSearch"></span></h5>
                        <?php else: ?>
                            <h5 style="display:none" class="showSearch">Busqueda: <span class="text-secondary textShowSearch"></span></h5>
                        <?php endif; ?>
                        <div class="form-inline mb-3">



                            <?php if(request()->categoria != null and request()->categoria != 'Todas'): ?>
                                <h5 style="display:" class="showCategory">Categoría: <span class="textShowCategory text-secondary"><?php echo e(request()->categoria); ?></span></h5>
                            <?php else: ?>
                                <h5 style="display:none" class="showCategory">Categoría: <span class="textShowCategory text-secondary"></span></h5>
                            <?php endif; ?>

                            <?php if(request()->tag != null and request()->tag != 'Todas'): ?>
                                <h5 style="display:" class="ml-5 showTag">Tag: <span class="textShowTag text-secondary"><?php echo e(request()->tag); ?></span></h5>
                            <?php else: ?>
                                <h5 style="display:none" class="ml-5 showTag">Tag: <span class="textShowTag text-secondary"></span></h5>
                            <?php endif; ?>


                        </div>
                        <div >
                            <div class="row">
                                <?php if($articles->first() == null): ?>
                                    <div class="col-12">
                                        <h5 class="text-center text-danger"><i class="fas fa-exclamation-circle"></i> Sin resultados para mostrar</h5>
                                    </div>
                                <?php else: ?>
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-6 col-md-4 col-lg-4 mb-4" style="margin:0;padding:2px">
                                            <a href="<?php echo e(route('article',$article->id)); ?>">
                                                <div class="card" style="height:100%;">
                                                    <div class="card-header">
                                                        <img style="object-fit:cover;border:solid 1px rgb(181, 178, 182);height:150px;width:100%" class="popular-course-thumb bg-img" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="mb-3" style="max-height:150px;overflow:hidden;">
                                                            <h6 class="text-center text-purple"><?php echo $article->title; ?></h6>
                                                            <div class="row">
                                                                <div class="col-12">
                                                                    <span class="" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></span>
                                                                    <span class="float-right text-dark" style="font-size:11px"><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <button class="btn bg-green btn-sm float-right" style="position:absolute;bottom:5px;right:10px;">Leer <i class="fas fa-chevron-right"></i> </button>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>

                        </div>
                    </div>
                    <div class="card-footer text-green font600">
                        Página nro <?php echo e($articles->currentPage()); ?> de
                        <input type="hidden" name="" value="<?php echo e($articles->currentPage()); ?>" class="form-control" id="numberPage">
                        <?php echo e($articles->lastPage()); ?>

                        <span class="pagination float-right"><?php echo e($articles->links()); ?></span>
                    </div>
                </div>
            </div>


            
            <div class="col-lg-3">
                <div class="card maxMdHide">
                    <div class="card-header bg-gradient">
                        <h5 class="text-white"><i class="fas fa-filter"></i> Filtros</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-4 col-lg-12">
                                <label for="">Nombre del Artículo</label>
                                <input type="text" name="" value="" class="form-control form-control-sm filterSearch">
                            </div>
                            <div class="col-12">
                                <?php if($categories->first() != Null): ?>
                                    <label for="">Categoría</label>
                                    <select class="form-control form-control-sm filterCategory" name="" >
                                        <?php if(request()->categoria == Null): ?>
                                            <option value="" selected>Todas</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <?php else: ?>

                                            <option value="">Todas</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(request()->categoria == $value->name): ?>

                                                    <option  value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                                                <?php else: ?>
                                                    <option  value="<?php echo e($value->id); ?>" ><?php echo e($value->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    </select>

                                <?php endif; ?>
                            </div>
                            <div class="col-12">
                                <?php if($tags->first() != Null): ?>
                                    <label for="">Etiqueta</label>
                                    <select class="form-control form-control-sm filterTag" name="">
                                        <option value="" selected>Todas</option>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value=""></option>
                                    </select>
                                <?php endif; ?>
                            </div>



                        <div class="col-12">
                            <button type="button" name="button" class="deleteSearch ml-1 btn bg-purple text-white mt-2 float-right" style="display:none"><i class="fas fa-backspace"></i> </button>
                            <button  type="button" name="button" class="searchArticles btn bg-green mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                        </div>
                        </div>
                    </div>

                </div>
                <?php if($categories->first() != Null): ?>
                    <div class="card mt-4">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white"><i class="fas fa-list-alt"></i> Categorías</h5>
                        </div>
                        <input type="hidden" name="" value="<?php echo e($number = 0); ?>">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <input type="hidden" name="hidden" value="<?php echo e($number = $number + 1); ?>" >
                            <hr style="margin:0px;padding:0px">

                            <div class="categoryS" data-val="<?php echo e($category->id); ?>">
                                <span class="font600"><?php echo e($category->name); ?> </span><span class="bg-green float-right text-center" style="border-radius:20px;width:20px"><?php echo e($category->articles->where('disabled','no')->count()); ?></span>
                            </div>
                            <hr style="margin:0px;padding:0px">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="categoryS" id="todos">
                            <span class="font600">Todos </span><span class="bg-green float-right text-center" style="border-radius:20px;width:20px"><?php echo e($articles->where('disabled','no')->count()); ?></span>
                        </div>

                    </div>
                <?php endif; ?>

                <?php if($tags->first() != Null): ?>

                    <div class="card my-4">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white">Etiquetas</h5>
                        </div>
                        <div class="card-body">
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" name="button" class="tagS btn btn-sm bg-green ml-1 mt-1" value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <br>
            <br>


        </div>


    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    function autorArticle(){
        value = $("#userAuth").val();
        $('.autorCreate').val(value);
    }

    $(document).ready(function() {
        $('.js-example-basic-multiple').select2();
    });

    $(document).on("click", ".pagination a", function(e){
        e.preventDefault();
        showLoader();
        var url = $(this).attr('href');
        if(!url.includes('articulos_ajax')){
            url = url.replace('articulos','articulos_ajax');
        }
        ajaxArticles(url);
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/articles/articles.blade.php ENDPATH**/ ?>