<footer class="bg-dark py-5 footer" style="">
    <div class="container2">

        <div class="row">
            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <h5 class="text-white"><i class="fas fa-map-marked-alt font600 text-success" style="font-size:30px !important"></i> Dirección:</h5>
                <h6 class="text-justify text-light"> Av. Mariana de Jesús y Jorge Juan N31-120, Quito - Ecuador</h6>
            </div>

            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <a href="https://api.whatsapp.com/send?phone=+593989558833" class="whatsapp-mobile">
                    <h5 class="text-white"><i class="fab fa-whatsapp-square text-success" style="font-size:35px !important"></i> Whatsapp:</h5>
                    <h6 class="text-light" > +593989558833 </h6>
                </a>
                <a href="https://web.whatsapp.com/send?phone=593989558833&text=" class="whatsapp-web">
                    <h5 class="text-white"><i class="fab fa-whatsapp-square text-success" style="font-size:37px !important"></i> Whatsapp:</h5>
                    <h6 class="text-light" > +593989558833 </h6>
                </a>
            </div>

            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <h5 class="text-white mb-2"><i class="fas fa-users text-success" style="font-size:30px !important"></i> Redes Sociales:</h5>
                <br>
                <a href="https://www.instagram.com/2v_tesis/?hl=es-la" target="_blank">
                    <h6 class="text-light">
                        <i class="fab fa-instagram-square text-success" style="font-size:25px;margin-top:-30px"></i> <span class="text-light" style="color:rgb(217, 220, 221)">@2v_tesis</span>
                    </h6>
                </a>
                <br>
                <a href="https://es-la.facebook.com/me.quiero.graduar.ya/" target="_blank" class="">
                    <h6 class="text-light">
                        <i class="fab fa-facebook-square text-success" style="font-size:25px;margin-top:-30px"></i> <span class="text-light" style="color:rgb(217, 220, 221)">2V Soluciones Académicas</span>
                    </h6>
                </a>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <h5 class="text-white mb-2"><i class="fas fa-envelope text-success" style="font-size:30px !important"></i> Correo:</h5>

                <h6 class="text-light">
                 <span class="text-light" style="color:rgb(217, 220, 221)">tulogroesnuestroexito2v@gmail.com</span>
                </h6>
                
            </div>

        </div>
    </div>

</footer>


    
<?php /**PATH C:\xampp\htdocs\2v\resources\views/layouts/footer.blade.php ENDPATH**/ ?>