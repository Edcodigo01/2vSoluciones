
<?php $__env->startSection('title'); ?>
    Admin / Artículos
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>


    <div class="row">
        <div class="col-12">
            
            <h2 class="mb-4 text-">Artículos</h2>
        </div>
    </div>

    <table style="width:100%" class="listar table table-bordered table-striped listar" data-route="list_articles" data-update="articleUpdate/{id}" id="table-articles" data-routeEnable="enabled_article/{id}" data-routeDisable="disable_article/{id}" data-delete="<?php echo e(url("administrar-articulos/{id}")); ?>">
        <thead>
            <tr>
                <th>Id</th>
                <th>Acciones:</th>
                <th>Título</th>
                <th>Autor</th>


            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

<?php echo $__env->make('articles.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('articles.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('articles.includes.modalEnable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('articles.includes.modalDisabled', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<input type="hidden" name="" value="<?php echo e($dataArticles); ?>" id="data">

<input type="hidden" name="" value="<?php echo e(Auth::user()->nameComplete); ?>" id="userAuth">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        function autorArticle(){
            value = $("#userAuth").val();
            $('.autorCreate').val(value);
        }

        $(document).ready(function() {
            $('.js-example-basic-multiple').select2();
        });

        $(document).on("click", ".pagination a", function(e){
            e.preventDefault();
            showLoader();
            var url = $(this).attr('href');
            if(!url.includes('articulos_ajax')){
                url = url.replace('articulos','articulos_ajax');
            }
            ajaxArticles(url);
        });

        CKEDITOR.replace('contentCreate',
        {
            wordcount: {
                showCharCount: true,
                maxCharCount: 20000
            }
        });
        CKEDITOR.replace('content',
        {
            wordcount: {
                showCharCount: true,
                maxCharCount: 20000
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2vR\resources\views/articles/articles.blade.php ENDPATH**/ ?>