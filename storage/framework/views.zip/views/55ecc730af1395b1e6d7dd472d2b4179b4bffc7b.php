
<?php $__env->startSection("content"); ?>
    <div class="" id="scrollPaginate">

    </div>

    <div class="text-center paralax" style="background-image: url('public/images/default/home/manosOk.jpg');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">


            <span class="bg-green px-3 py-2" style="display:inline-block">
                <h3 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-comments"></i> Testimonios</h3>
            </span>

        </div>

    </div>



    <br>

    <div class="container2">
        <h4 class="text-purple text-center my-3"> ¿Ya has disfrutado de nuestros servicios? Por favor déjanos saber tu opinión acerca de nosotros.</h4>

        <br>
        <div class="containerScroll bg-white" style="border-radius:10px;border:solid 1px rgb(219, 212, 216);overflow-y:auto;">
            <div class="fb-comments" data-href="https://2vsoluciones.com/2v/" data-numposts="5" data-width="100%" style="padding-left:30px;padding-right:30px"></div>

        </div>
    </div>
    <br>
    <br>
    <h4 class="text-center text-dark">Para ver más comentarios ingresa a nuestra cuenta de facebook</h4>
    <div class="text-center">
        <a target="_blank" href="https://business.facebook.com/me.quiero.graduar.ya/?business_id=301312427099496"><img src="<?php echo e(asset('public\images\default\redes sociales\logo-facebook.jpg')); ?>" alt="" style="border-radius:5px;max-width:60px">
        <p class="text-center">ClicK Aqui</p></a>
    </div>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v7.0&appId=201064434390930&autoLogAppEvents=1" nonce="EAUQffoA"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/testimonios.blade.php ENDPATH**/ ?>