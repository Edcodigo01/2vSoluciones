<div class="modal fade" id="modalDeleteAJAX" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:700px !important">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h3 class="modal-title" id="exampleModalLabel"><i class="fas fa-exclamation-triangle mr-2"></i>Atención</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h4 class="" style="color:red">¿Estas segur@ de eliminar este video?</h4>
            </div>
            <div class="modal-footer">
                <form action="" class="formula form-delete" method="DELETE" id="form-delete">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-times"></i> Cancelar</button>
                    <button class="btn btn-danger" name="button"><i class="fas fa-exclamation-triangle"></i> Aceptar</button>
                </form>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/videos/includes/modalDeleteAJAX.blade.php ENDPATH**/ ?>