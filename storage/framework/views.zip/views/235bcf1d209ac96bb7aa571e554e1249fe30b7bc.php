<div class="" id="loader">
    <div class="loader-background">
        
    </div>
    <div class="loader loader-1">
      <div class="loader-outter"></div>
      <div class="loader-inner"></div>
    </div>
</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/layouts/loader.blade.php ENDPATH**/ ?>