
<?php $__env->startSection("content"); ?>

    
    <div class="text-center paralax" style="background-image: url('<?php echo e(asset($article->imageP)); ?>');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">

            
            <span class="bg-green px-3 py-2" style="display:inline-block">
                <h3 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-book-open"></i> <?php echo e($article->title); ?></h3>
            </span>
        </div>

    </div>
    <div class="" id="scrollPaginate">

    </div>
    <div class="container2 mt-4">
        
        <div class="row">

            
            <div class="filterMdArticles" style="display:none">
                <div class="col-12 maxMdShow  mb-2" >
                    <div class="card">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white"><i class="fas fa-filter"></i> Filtros Articulos</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6 col-md-4 col-lg-12">
                                    <label for="">Nombre</label>
                                    <input type="text" name="" value="" class="form-control form-control-sm filterSearch">
                                </div>
                                <div class="col-6 col-md-4">
                                    <?php if($categories->first() != Null): ?>
                                        <label for="">Categoría</label>
                                        <select class="form-control form-control-sm filterCategory" name="">
                                            <?php if(request()->categoria == Null): ?>
                                                <option value="" selected>Todas</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            <?php else: ?>

                                                <option value="">Todas</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(request()->categoria == $value->name): ?>

                                                        <option  value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>
                                        </select>

                                    <?php endif; ?>
                                </div>
                                <div class="col-6 col-md-4">
                                    <?php if($tags->first() != Null): ?>
                                        <label for="">Etiqueta</label>
                                        <select class="form-control form-control-sm filterTag" name="">
                                            <option value="" selected>Todas</option>
                                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <option value=""></option>
                                        </select>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <button type="button" name="button" class="deleteSearch ml-1 btn bg-purple text-white mt-2 float-right" style="display:none"><i class="fas fa-backspace"></i> </button>
                            <button type="button" name="button" class="searchArticles btn bg-green mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-9 mb-4" id="viewAjax">
                <div class="card">

                    <div class="card-body">
                        <div class="col-12">
                            <a class="venobox maxMdHide" href="<?php echo e(asset($article->imageP)); ?>" data-gall="myGallery">

                                <img src="<?php echo e(asset($article->imageP)); ?>" alt="" style="" class="imageP">
                            </a>


                            <h5 class="mt-2" ><?php echo e($article->title); ?></h5>
                            <?php if($article->category != Null): ?>
                                <h6 class="text-purple">Categoria: <span class="text-secondary"> <?php echo e($article->category->name); ?> </span></h6>
                            <?php endif; ?>
                            <h6 class="text-purple">Autor: <span class="text-secondary"> <?php echo e($article->autor); ?> </span></h6>
                            <h6 class="text-purple">Fecha: <span class="text-secondary"> <?php echo e(\Carbon\Carbon::parse($article->created_at)->format('d-m-Y')); ?> </span></h6>
                            <?php if($tagsArticle->first() != null): ?>
                                <input type="hidden" name="" value="<?php echo e($tagCount = $tagsArticle->count()); ?>" class="form-control">

                            <p class="text-purple">Etiquetas:
                                <input type="hidden" name="" value="<?php echo e($number = 1); ?>" class="form-control " >
                                <?php $__currentLoopData = $tagsArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="text-secondary"> <?php echo e($value->tag->name); ?><?php if($number != $tagCount): ?>,<?php else: ?>. <?php endif; ?> </span>
                                        <input type="hidden" name="" value="<?php echo e($number = $number + 1); ?>" class="form-control ">

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                                <?php endif; ?>


                            <img src="<?php echo e(asset($article->imageP)); ?>" alt="" class="imagePMobile maxMdShow">
                            <p><?php echo $article->content; ?></p>


                            <div class="row mt-2">
                                <?php if($article->imageA1): ?>
                                    <div class="col-md-6">
                                        <a class="venobox" href="<?php echo e(asset($article->imageA1)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA1)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>

                                    </div>
                                <?php endif; ?>
                                <?php if($article->imageA2): ?>
                                    <div class="col-md-6">
                                        <a class="venobox " href="<?php echo e(asset($article->imageA2)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA2)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>

                                    </div>
                                <?php endif; ?>
                                <?php if($article->imageA3): ?>
                                    <div class="col-md-6">
                                        <a class="venobox " href="<?php echo e(asset($article->imageA3)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA3)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>

                                    </div>
                                <?php endif; ?>
                                <?php if($article->imageA4): ?>
                                    <div class="col-md-6">
                                        <a class="venobox" href="<?php echo e(asset($article->imageA4)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA4)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php if($articlesRelated->first() != Null): ?>
                    
                    <div class="card mt-5 mb-4 mobileShow">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white">Artículos Relacionados</h5>
                        </div>
                        <div class="card-body">
                            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                              <div class="carousel-inner">
                                  <input type="hidden" name="" value="<?php echo e($numberA = 0); ?>" class="form-control " >
                                  <?php $__currentLoopData = $articlesRelated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <input type="hidden" name="" value="<?php echo e($numberA = $numberA + 1); ?>" class="form-control " >
                                      <div class="carousel-item <?php if($numberA == 1): ?>active <?php endif; ?> container">

                                              <a href="<?php echo e(route('article',$article->id)); ?>">
                                              <div class="card wow fadeInLeft" style="height:100%;" data-wow-delay="">
                                                  <div class="card-header">
                                                      <img style="object-fit:cover;border:solid 1px rgb(181, 178, 182);height:150px;width:100%" class="popular-course-thumb bg-img" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                                                  </div>
                                                  <div class="card-body">
                                                      <div class="mb-3" style="max-height:150px;overflow:hidden;">
                                                          <h6 class="text-center text-purple"><?php echo $article->title; ?></h6>
                                                          <div class="row">
                                                              <div class="col-12">
                                                                  <span class="" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></span>
                                                                  <span class="float-right text-dark" style="font-size:11px"><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></span>
                                                              </div>
                                                          </div>
                                                      </div>

                                                      <button  class="btn bg-green btn-sm float-right" style="position:absolute;bottom:5px;right:10px;">Leer <i class="fas fa-arrow-right"></i> </button>
                                                  </div>
                                              </div>
                                              </a>

                                      </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                              </div>
                              <?php if($articlesRelated->count() > 1): ?>
                                  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon " aria-hidden="true"></span>
                                    <span class="sr-only">Anterior</span>
                                  </a>
                                  <a class="carousel-control-next text-danger" href="#carouselExampleControls" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Siguiente</span>
                                  </a>
                              <?php endif; ?>
                            </div>


                        </div>
                    </div>
                    
                    <div class=" mobileHide">
                        <div class="card mt-5 mb-2">
                            <div class="card-header bg-gradient">
                                <h5 class="text-white">Artículos Relacionados</h5>
                            </div>
                            <div class="card-body row">
                                <?php $__currentLoopData = $articlesRelated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4 col-lg-3 mb-4" style="margin:0;padding:0">
                                        <a href="<?php echo e(route('article',$article->id)); ?>">
                                            <div class="card" style="height:100%;">
                                                <div class="card-header">
                                                    <img style="object-fit:cover;border:solid 1px rgb(181, 178, 182);height:150px;width:100%" class="popular-course-thumb bg-img" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                                                </div>
                                                <div class="card-body">
                                                    <div class="mb-3" style="max-height:150px;overflow:hidden;">
                                                        <h6 class="text-center text-purple"><?php echo $article->title; ?></h6>
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <span class="" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></span>
                                                                <span class="float-right text-dark" style="font-size:11px"><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <button class="btn bg-green btn-sm float-right" style="position:absolute;bottom:5px;right:10px;">Leer <i class="fas fa-chevron-right"></i> </button>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>

                <?php endif; ?>




            </div>


            
            <div class="col-lg-3">
                <div class="card maxMdHide">
                    <div class="card-header bg-gradient">
                        <h5 class="text-white"><i class="fas fa-filter"></i> Filtros</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-4 col-lg-12">
                                <label for="">Nombre del Artículo</label>
                                <input type="text" name="" value="" class="form-control form-control-sm filterSearch">
                            </div>
                            <div class="col-12">
                                <?php if($categories->first() != Null): ?>
                                    <label for="">Categoría</label>
                                    <select class="form-control form-control-sm filterCategory" name="" >
                                        <?php if(request()->categoria == Null): ?>
                                            <option value="" selected>Todas</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <?php else: ?>

                                            <option value="">Todas</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(request()->categoria == $value->name): ?>

                                                    <option  value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                                                <?php else: ?>
                                                    <option  value="<?php echo e($value->id); ?>" ><?php echo e($value->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    </select>

                                <?php endif; ?>
                            </div>
                            <div class="col-12">
                                <?php if($tags->first() != Null): ?>
                                    <label for="">Etiqueta</label>
                                    <select class="form-control form-control-sm filterTag" name="">
                                        <option value="" selected>Todas</option>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value=""></option>
                                    </select>
                                <?php endif; ?>
                            </div>



                        <div class="col-12">
                            <button type="button" name="button" class="deleteSearch ml-1 btn bg-purple text-white mt-2 float-right" style="display:none"><i class="fas fa-backspace"></i> </button>
                            <button  type="button" name="button" class="searchArticles btn bg-green mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                        </div>
                        </div>
                    </div>

                </div>

                <div class="maxMdShow filterMdArticle mb-2">
                    <div class="card">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white"><i class="fas fa-filter"></i> Filtros Articulos</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6 col-md-4 col-lg-12">
                                    <label for="">Nombre</label>
                                    <input type="text" name="" value="" class="form-control form-control-sm filterSearch">
                                </div>
                                <div class="col-6 col-md-4">
                                    <?php if($categories->first() != Null): ?>
                                        <label for="">Categoría</label>
                                        <select class="form-control form-control-sm filterCategory" name="">
                                            <?php if(request()->categoria == Null): ?>
                                                <option value="" selected>Todas</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            <?php else: ?>

                                                <option value="">Todas</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(request()->categoria == $value->name): ?>

                                                        <option  value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>
                                        </select>

                                    <?php endif; ?>
                                </div>
                                <div class="col-6 col-md-4">
                                    <?php if($tags->first() != Null): ?>
                                        <label for="">Etiqueta</label>
                                        <select class="form-control form-control-sm filterTag" name="">
                                            <option value="" selected>Todas</option>
                                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <option value=""></option>
                                        </select>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <button type="button" name="button" class="deleteSearch ml-1 btn bg-purple text-white mt-2 float-right" style="display:none"><i class="fas fa-backspace"></i> </button>
                            <button type="button" name="button" class="searchArticles btn bg-green mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                        </div>
                    </div>
                </div>

                <?php if($categories->first() != Null): ?>
                    <div class="card mt-4">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white"><i class="fas fa-list-alt"></i> Categorías</h5>
                        </div>
                        <input type="hidden" name="" value="<?php echo e($number = 0); ?>">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <input type="hidden" name="hidden" value="<?php echo e($number = $number + 1); ?>" >
                            <hr style="margin:0px;padding:0px">

                            <div class="categoryS" data-val="<?php echo e($category->id); ?>">
                                <span class="font600"><?php echo e($category->name); ?> </span><span class="bg-green float-right text-center" style="border-radius:20px;width:20px"><?php echo e($category->articles->where('disabled','no')->count()); ?></span>
                            </div>
                            <hr style="margin:0px;padding:0px">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="categoryS" id="todos">
                            <span class="font600">Todos </span><span class="bg-green float-right text-center" style="border-radius:20px;width:20px"><?php echo e($articles->where('disabled','no')->count()); ?></span>
                        </div>

                    </div>
                <?php endif; ?>

                <?php if($tags->first() != Null): ?>

                    <div class="card my-4">
                        <div class="card-header bg-gradient">
                            <h5 class="text-white">Etiquetas</h5>
                        </div>
                        <div class="card-body">
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" name="button" class="tagS btn btn-sm bg-green ml-1 mt-1" value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <br>
            <br>


        </div>


    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    function autorArticle(){
        value = $("#userAuth").val();
        $('.autorCreate').val(value);
    }

    $(document).ready(function() {
        $('.js-example-basic-multiple').select2();
    });

    $(document).on("click", ".pagination a", function(e){
        e.preventDefault();
        showLoader();
        var url = $(this).attr('href');
        if(!url.includes('articulos_ajax')){
            url = url.replace('articulos','articulos_ajax');
        }
        ajaxArticles(url);
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/article/article.blade.php ENDPATH**/ ?>