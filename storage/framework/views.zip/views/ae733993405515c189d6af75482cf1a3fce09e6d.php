<div id="filtersMobile" class="mt-1">
   <div class="row">
       <div class="col-12">
           <a class="btnCloseFilterMobile float-right mr-2"> <i class="fas fa-times"></i> </a>
       </div>
   </div>

   <div class="card">
        <div class="card-body">
           <h6 class="text-green-l"> Filtros</h6>
           <form  class="" action="<?php echo e(url('articulos')); ?>" method="get" id="formSearchPost">

              <div class="row">
                 <div class="col-12">
                     <label for="">Título del artículo</label>
                     <input type="text" name="titulo" value="<?php echo e(request()->titulo); ?>" class="form-control form-control-sm">
                 </div>
                 <div class="col-12">
                     <?php if($categories->first() != Null): ?>
                         <label for="">Categoría</label>
                         <select class="form-control form-control-sm" name="categoria" >
                             <?php if(request()->categoria == Null): ?>
                                 <option value="" selected class="">Todas</option>
                                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option  value="<?php echo e($value->name); ?>" class=""><?php echo e($value->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php else: ?>

                                 <option value="" class="">Todas</option>
                                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if(request()->categoria == $value->name): ?>
                                         <option class="" value="<?php echo e($value->name); ?>" selected><?php echo e($value->name); ?></option>
                                     <?php else: ?>
                                         <option class="" value="<?php echo e($value->name); ?>" ><?php echo e($value->name); ?></option>
                                     <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             <?php endif; ?>
                         </select>

                     <?php endif; ?>
                 </div>
             <div class="col-12">
                <?php if(request()->titulo or request()->categoria): ?>
                   <a href="<?php echo e(url('articulos')); ?>" type="button" name="button" class="ml-1 btn btn-purple text-white mt-2 float-right" style=""><i class="fas fa-backspace"></i> </a>
                <?php endif; ?>

                 <button  type="submit" name="button" class="btn btn-purple mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
             </div>
             </div>
           </form>
        </div>

   </div>

   <?php if($categories->first() != Null): ?>
        <div class="card mt-2">
            <div class="card-body">
               <h6 class="text-green-l"> Categorías</h6>
               <input type="hidden" name="" value="<?php echo e($number = 0); ?>">
               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <input type="hidden" name="hidden" value="<?php echo e($number = $number + 1); ?>" >
                  <hr style="margin:0px;padding:0px">

                  <div class="searchCategory" data-val="<?php echo e($category->name); ?>">
                       <span class="font600"><?php echo e($category->name); ?> </span><span class="bg-green-l float-right text-center" style="border-radius:20px;width:20px"><?php echo e($category->articles->where('disabled','no')->count()); ?></span>
                  </div>
                  <hr style="margin:0px;padding:0px">
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <div class="searchCategory" id="todos" data-val="">
                  <span class="font600">Todas </span><span class="bg-green-l float-right text-center" style="border-radius:20px;width:20px"><?php echo e($articles->where('disabled','no')->count()); ?></span>
               </div>

            </div>
        </div>
   <?php endif; ?>
</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/front/articles/filtersMobile.blade.php ENDPATH**/ ?>