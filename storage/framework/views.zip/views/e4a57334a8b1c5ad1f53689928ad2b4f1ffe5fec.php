<div class="">

    <div id="fixedsocial" class="bg-gradien text-center">
        <div class=""><a target="_blank" href="https://www.instagram.com/2v_tesis/?hl=es-la"><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-instagram.jpg')); ?>" alt=""></a></div>
        <div class=""><a target="_blank" href="https://es-la.facebook.com/me.quiero.graduar.ya/"><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-facebook.jpg')); ?>" alt=""></a></div>



        
        <div class="whatsapp-mobile"><a target="_blank" href="https://api.whatsapp.com/send?phone=+593989558833"><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-whatsapp.jpg')); ?>" alt=""></a></div>

        <div class="whatsapp-web" style="display:none"><a target="_blank" href="https://web.whatsapp.com/send?phone=593989558833&text="><img class="social-icon" src="<?php echo e(asset('public\images\default\redes sociales\logo-whatsapp.jpg')); ?>" alt=""></a></div>
    </div>



</div>
<?php /**PATH C:\xampp\htdocs\2v\resources\views/layouts/fixedSocial.blade.php ENDPATH**/ ?>