
<?php $__env->startSection('title'); ?>
    Inicio de sesión
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
   <div style="height:170px">

   </div>
    <div class="bg-" style="">
        <div class="card mt-5 m-auto" style="width:350px !important">
            <div class="card-body ">
                <div class="text-center">
                    <img src="<?php echo e(asset('public\images\default\logos\logo-t.png')); ?>" alt="" style="width:100px" class="text-center">
                </div>

                    <h5 class="text-center text-purple-l">Iniciar Sesión</h5>
                    
                    <form class="formula validate" action="<?php echo e(route('login')); ?>" method="post" id="form-login">
                        <div class="form-group">
                            <label for="" class="" ><i class="fas fa-envelope"></i> Email</label>
                            <input type="text" name="email" value="2v@admin.com" class="form-control required">
                        </div>
                        <div class="form-group">
                            <label for="" class="" ><i class="fas fa-envelope"></i> Contraseña</label>
                            <input type="password" name="password" value="" class="form-control required password" id="blockMayus">
                        </div>
                        <div class="form-group">
                            <button type="submit" name="button" class="btn bg-purple btn-block">Iniciar Sesión</button>
                            <button type="button" name="button" class="btn btn-light btn-block">Cancelar / Inicio</button>

                        </div>
                    </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("front.layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/admin/adminIni.blade.php ENDPATH**/ ?>