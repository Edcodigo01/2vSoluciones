<div class="navP">
   <div class="containerNav relative form-inline" style="height:100%">
         <div style="height:100%" class="zone-logo">

            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public\images\default\logos\logo-2v-sinfondo-trangular-sm.png')); ?>" alt="" class="logo-n"></a>
            
        </div>
         <div style="" class="text-center linksN zone-links" style="height:100%">
            <a href="<?php echo e(url('/')); ?>" class="linkN  <?php if(url('/') == url()->current()): ?> active <?php endif; ?>">Inicio</a>
            <a href="<?php echo e(url('servicios')); ?>" class="linkN  <?php if(url('servicios') == url()->current()): ?> active  <?php endif; ?>">Servicios</a>
            <a href="<?php echo e(url('nosotros')); ?>" class="linkN  <?php if(url('nosotros') == url()->current()): ?> active <?php endif; ?>">Nosotros</a>
               <a href="<?php echo e(url('testimonios')); ?>" class="linkN  <?php if(url('testimonios') == url()->current()): ?> active <?php endif; ?>">Testimonios</a>
            <a href="<?php echo e(url('videos')); ?>" class="linkN  <?php if(url('videos') == url()->current()): ?> active <?php endif; ?>">Videos</a>
               <a href="<?php echo e(url('articulos')); ?>" class="linkN  <?php if(url('articulos') == url()->current()): ?> active <?php endif; ?>">Artículos</a>
            <a href="<?php echo e(url('contactanos')); ?>" class="linkN  <?php if(url('contactanos') == url()->current()): ?> active <?php endif; ?>">Contáctanos</a>
         </div>
         <a type="button" name="button" class="float-right btn-main ml-auto mt-1" style="font-size:30px"> <i class="fas fa-bars"></i> </a>
   </div>
</div>

<div class="navP navP2" >
    <div class="containerNav relative form-inline" style="height:100%">
          <div style="height:100%" class="zone-logo">

             <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public\images\default\logos\logo-2v-sinfondo-trangular-sm.png')); ?>" alt="" class="logo-n"></a>
             
         </div>
          <div style="" class="text-center " style="height:100%">
             <a href="<?php echo e(url('/')); ?>" class="linkN  <?php if(url('/') == url()->current()): ?> active <?php endif; ?>">Inicio</a>
             <a href="<?php echo e(url('servicios')); ?>" class="linkN  <?php if(url('servicios') == url()->current()): ?> active  <?php endif; ?>">Servicios</a>
             <a href="<?php echo e(url('nosotros')); ?>" class="linkN  <?php if(url('nosotros') == url()->current()): ?> active <?php endif; ?>">Nosotros</a>
                <a href="<?php echo e(url('testimonios')); ?>" class="linkN  <?php if(url('testimonios') == url()->current()): ?> active <?php endif; ?>">Testimonios</a>
             <a href="<?php echo e(url('videos')); ?>" class="linkN  <?php if(url('videos') == url()->current()): ?> active <?php endif; ?>">Videos</a>
                <a href="<?php echo e(url('articulos')); ?>" class="linkN  <?php if(url('articulos') == url()->current()): ?> active <?php endif; ?>">Artículos</a>
             <a href="<?php echo e(url('contactanos')); ?>" class="linkN  <?php if(url('contactanos') == url()->current()): ?> active <?php endif; ?>">Contáctanos</a>
          </div>
          <a type="button" name="button" class="float-right btn-main ml-auto mt-1 text-dark" style="font-size:30px"> <i class="fas fa-bars"></i> </a>
    </div>
</div>

<div class="spaceNavbar">

</div>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/front/layouts/navbar.blade.php ENDPATH**/ ?>