<div class="main">
   <span class="close-main float-right mr-2"> <i class="fas fa-times"></i> </span>
   <span class="ml-2">Menú</span>
   <div class="content">
      <a href="<?php echo e(url('/')); ?>" class="  <?php if(url('/') == url()->current()): ?> active <?php endif; ?>">Inicio</a>
      <a href="<?php echo e(url('servicios')); ?>" class="  <?php if(url('servicios') == url()->current()): ?> active <?php endif; ?>">Servicios</a>
      <a href="<?php echo e(url('nosotros')); ?>" class="  <?php if(url('nosotros') == url()->current()): ?> active <?php endif; ?>">Nosotros</a>
      <a href="<?php echo e(url('testimonios')); ?>" class="  <?php if(url('testimonios') == url()->current()): ?> active <?php endif; ?>">Testimonios</a>
      <a href="<?php echo e(url('videos')); ?>" class="  <?php if(url('videos') == url()->current()): ?> active <?php endif; ?>">Videos</a>
      <a href="<?php echo e(url('articulos')); ?>" class="  <?php if(url('articulos') == url()->current()): ?> active <?php endif; ?>">Artículos</a>
      <a href="<?php echo e(url('contactanos')); ?>" class="  <?php if(url('contactanos') == url()->current()): ?> active <?php endif; ?>">Contáctanos</a>
   </div>
   </div>
</div><?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/front/layouts/main.blade.php ENDPATH**/ ?>