
<?php $__env->startSection("content"); ?>

    
    
    <div class="text-center paralax" style="background-image: url(<?php echo e(asset('public/images/default/libros.jpg')); ?>);background-position:bottom">
        <div class="container-title" style="background:rgba(36, 35, 35, 0.48)">
            <span class="bg- px-3 py-2" style="display:inline-block">
                <h2 class="text-center text-white mt-1 titleArticle" style="max-width:1000px;margin:auto"><i class="fas fa-book-open"></i> <?php echo e($article->title); ?></h2>
            </span>
        </div>
    </div>

    <div class="container2 mt-4">
      <?php echo $__env->make('front.articles.filtersMobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="row">
          <div class="col-12 p-1">
               <button type="button" name="button" class="btn btn-purple btn-sm m-0 mb-1 float-right btnFiltersMobile"><i class="fas fa-search"></i> Buscar</button>
          </div>
     </div>
        
        <div class="row">
            <div class="col-lg-8 col-xl-9 mb-4 px-1" id="viewAjax">
                <div class="card">
                    <div class="card-body p-2">

                        <img src="<?php echo e(asset($article->imageP)); ?>" alt="" style="" class="imageP mb-4">


                        <div class="col-12">

                            <h6 class="" ><?php echo e($article->title); ?> </h6>
                            <?php if($article->category != Null): ?>
                                <p class="my-1 text-purple">Categoria: <span class="text-secondary"> <?php echo e($article->category->name); ?> </span></p>
                            <?php endif; ?>
                            <p class="my-1 text-purple">Autor: <span class="text-secondary"> <?php echo e($article->autor); ?> </span></p>
                            <p class="my-1 text-purple">Fecha: <span class="text-secondary"> <?php echo e(\Carbon\Carbon::parse($article->created_at)->format('d-m-Y')); ?> </span></p>
                            <?php if($tagsArticle->first() != null): ?>
                                <input type="hidden" name="" value="<?php echo e($tagCount = $tagsArticle->count()); ?>" class="form-control">

                            <p class="text-purple">Etiquetas:
                                <input type="hidden" name="" value="<?php echo e($number = 1); ?>" class="form-control " >
                                <?php $__currentLoopData = $tagsArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="text-secondary"> <?php echo e($value->tag->name); ?><?php if($number != $tagCount): ?>,<?php else: ?>. <?php endif; ?> </span>
                                        <input type="hidden" name="" value="<?php echo e($number = $number + 1); ?>" class="form-control ">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                                <?php endif; ?>
                            <p><?php echo $article->content; ?></p>
                            <div class="row mt-2">
                                <?php if($article->imageA1): ?>
                                    <div class="col-md-6">
                                        <a class="venobox" href="<?php echo e(asset($article->imageA1)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA1)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>
                                    </div>
                                <?php endif; ?>
                                <?php if($article->imageA2): ?>
                                    <div class="col-md-6">
                                        <a class="venobox " href="<?php echo e(asset($article->imageA2)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA2)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>
                                    </div>
                                <?php endif; ?>
                                <?php if($article->imageA3): ?>
                                    <div class="col-md-6">
                                        <a class="venobox " href="<?php echo e(asset($article->imageA3)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA3)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>
                                    </div>
                                <?php endif; ?>
                                <?php if($article->imageA4): ?>
                                    <div class="col-md-6">
                                        <a class="venobox" href="<?php echo e(asset($article->imageA4)); ?>" data-gall="myGallery"><img src="<?php echo e(asset($article->imageA4)); ?>" alt="" class="float-right img-fluid imageGalleryBlog"></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>


                <h5 class="mt-5">Artículos Recientes</h5>
               <div class="row px-2">
                  <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-6 col-sm-4 col-md-4 col-lg-4 col-xl-3 mb-4 px-1 articlesList">
                         <a href="<?php echo e(route('article',$article->id)); ?>">
                         <div class="card wow fadeInLeft cardArticle" style="height:100%;" data-wow-delay="">
                             <div class="card-header p-1 border-g">
                                 <img style="" class="" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                             </div>
                             <div class="card-body border-g">
                                 <div class="my2-1" style="overflow:hidden;">
                                    <div class="containerTitle">
                                       <p class="text-center text-dark font600"><?php echo e(ucfirst(strtolower($article->title))); ?></p>
                                    </div>

                                 </div>
                                 <p class="text-dark mt-2" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></p>

                                 <button type="button" name="button" class="btn btn-sm btn-purple float-right">Leer</button>
                                 <p class="float-left text-dark mt-2 date" style=""><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></p>
                                 
                             </div>
                         </div>
                         </a>
                     </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>
            </div>
            
            <div class="col-lg-4 col-xl-3 px-1 filtersLG">
                <div class="card">
                    <div class="card-body">
                       <h6 class="text-green-l"> Filtros</h6>
                       <form  class="" action="<?php echo e(url('articulos')); ?>" method="get" id="formSearchPost">

                          <div class="row">
                             <div class="col-12 col-md-4 col-lg-12">
                                 <label for="">Título del artículo</label>
                                 <input type="text" name="titulo" value="<?php echo e(request()->titulo); ?>" class="form-control form-control-sm">
                             </div>
                             <div class="col-12">
                                 <?php if($categories->first() != Null): ?>
                                     <label for="">Categoría</label>
                                     <select class="form-control form-control-sm" name="categoria" >
                                         <?php if(request()->categoria == Null): ?>
                                             <option value="" selected class="">Todas</option>
                                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option  value="<?php echo e($value->name); ?>" class=""><?php echo e($value->name); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php else: ?>

                                             <option value="" class="">Todas</option>
                                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <?php if(request()->categoria == $value->name): ?>

                                                     <option class="" value="<?php echo e($value->name); ?>" selected><?php echo e($value->name); ?></option>
                                                 <?php else: ?>
                                                     <option class="" value="<?php echo e($value->name); ?>" ><?php echo e($value->name); ?></option>
                                                 <?php endif; ?>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                         <?php endif; ?>
                                     </select>

                                 <?php endif; ?>
                             </div>
                         <div class="col-12">
                            <?php if(request()->titulo or request()->categoria): ?>
                               <a href="<?php echo e(url('articulos')); ?>" type="button" name="button" class="ml-1 btn btn-purple text-white mt-2 float-right" style=""><i class="fas fa-backspace"></i> </a>
                            <?php endif; ?>

                             <button  type="submit" name="button" class="btn btn-purple mt-2 float-right" ><i class="fas fa-search ml-1"></i> Buscar</button>
                         </div>
                         </div>
                       </form>
                    </div>

                </div>

                <?php if($categories->first() != Null): ?>
                    <div class="card mt-4">
                        <div class="card-body">
                           <h6 class="text-green-l"> Categorías</h6>
                           <input type="hidden" name="" value="<?php echo e($number = 0); ?>">
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <input type="hidden" name="hidden" value="<?php echo e($number = $number + 1); ?>" >
                              <hr style="margin:0px;padding:0px">

                              <div class="searchCategory" data-val="<?php echo e($category->name); ?>">
                                   <span class="font600"><?php echo e($category->name); ?> </span><span class="bg-green-l float-right text-center" style="border-radius:20px;width:20px"><?php echo e($category->articles->where('disabled','no')->count()); ?></span>
                              </div>
                              <hr style="margin:0px;padding:0px">
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div class="searchCategory" id="todos" data-val="">
                              <span class="font600">Todas </span><span class="bg-green-l float-right text-center" style="border-radius:20px;width:20px"><?php echo e($articles->where('disabled','no')->count()); ?></span>
                           </div>

                        </div>
                    </div>
                <?php endif; ?>

            </div>
            <br>
            <br>

        </div>

        <div class="row">
           <div class="col-12 p-1">
               <button type="button" name="button" class="btn btn-purple btn-sm m-0 mb-1 float-right btnFiltersMobile"><i class="fas fa-search"></i> Buscar</button>
               <button type="button" name="button" class="btn btn-light btn-sm m-0 mb-1  btnBack"><i class="fas fa-backward"></i> Atras</button>
           </div>
      </div>

    </div>
    <br>
    <br>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    $(document).on('submit','#formSearchPost', function(e){
      e.preventDefault();
      titulo = $(this).find('input[name="titulo"]').val();
      category = $(this).find('select[name="categoria"]').val();
      if (titulo.length != 0) {
         titulo = 'titulo='+titulo;
      }else{
         titulo = '';
      }
      if (category.length != 0) {
         category = 'categoria='+category;
      }else{
         category = '';
      }

      if (category.length != 0 && titulo.length != 0) {
         $and = '&';
      }else{
         $and = '';
      }
      if (category.length != 0 || titulo.length != 0) {

         $interrogation = '?';
      }else{


         $interrogation = '';
      }
      window.location.href = '<?php echo e(url('articulos')); ?>'+$interrogation+category+$and+titulo;
    });


    $(document).on('click','.searchCategory', function(e){

      category = $(this).attr('data-val');
      if (category.length != 0 && category != '') {
         category = '?categoria='+category;
      }else{
         category = '';
      }

      window.location.href = '<?php echo e(url('articulos')); ?>'+category;

    });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("front.layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/front/article/article.blade.php ENDPATH**/ ?>