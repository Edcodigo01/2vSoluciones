<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?php echo e(asset('public\libraries\adminLTE\css\adminlte.min.css')); ?>">

  <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <link rel="stylesheet" href="<?php echo e(asset('public\libraries\js\select2\css\select2.css')); ?>">
  <link rel="icon" href="<?php echo e(asset('public/images/default/logos/logo-sm.jpg')); ?>">

  <style media="screen">
      .card{
          border: solid 1px rgb(193, 193, 193);
      }

      @media (max-width: 576px) {
         .logo-n-exito-nosotros{
            width: 200px;
         }

         .container2{
            width: 99%;

            padding: 0;
         }
         .card-body{
             padding: 5px;
         }
      }

      .btn{
          border: 1px solid rgb(226, 226, 226);
      }
  </style>
</head>
<body class="hold-transition sidebar-mini sidebar-collapse sidebar-closed layout-navbar-fixed layout-fixed">

    <?php echo $__env->make("layouts.loader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Site wrapper -->
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-dark navbar-light font600" style="padding:8px;font-size:16px;color:white">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link text-white" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

        <?php if(Auth::check()): ?>
            <div class="dropdown show">
              <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(Auth::user()->email); ?>

              </a>

              <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"> <i class="fas fa-sign-out-alt"></i> Cerrar Sessión</a>
              </div>
            </div>

        <?php endif; ?>
      
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->

  <?php echo $__env->make('layoutsAdmin.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper bg-white">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
        <br>
        <div class="container2 mt-5">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('public\js\langauage.js')); ?>"></script>

<script src="<?php echo e(asset('public\libraries\ckeditor4-standar-custom\ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('public\libraries\js\select2\js\select2.full.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>



<?php echo $__env->make('layoutsAdmin.modalsGlobal.modal_danger', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/layoutsAdmin/index.blade.php ENDPATH**/ ?>