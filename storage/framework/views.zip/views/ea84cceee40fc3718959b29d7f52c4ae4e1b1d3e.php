<div class="bg- pt-5 site-footer" style="">
    <div class="container2">
        <div class="row">
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <h6 class="text-white"><i class="fas fa-map-marked-alt font600 text-green" style=" !important"></i> Dirección:</h6>
                <p class="text- text-light"> Av. Mariana de Jesús y Jorge Juan N31-120, Quito - Ecuador</p>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <a href="https://api.Whatsapp.com/send?phone=+593989558833" class="whatsapp-mobile">
                    <h6 class="text-white"><i class="fab fa-whatsapp text-green" style=""></i> WhatsApp:</h6>
                    <p class="text-light link" > +593989558833 </p>
                </a>
                <a href="https://web.Whatsapp.com/send?phone=593989558833&text=" class="whatsapp-web">
                    <h6 class="text-white"><i class="fab fa-whatsapp text-green" style=""></i> WhatsApp:</h6>
                    <p class="text-light link" > +593989558833 </p>
                </a>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <h6 class="text-white mb-3"><i class="fas fa-users text-green" style=""></i> Redes Sociales:</h6>
                <a href="https://www.instagram.com/2v_tesis/?hl=es-la" target="_blank" style="display:inline-block">
                    <h5 class="text-light">
                       <i class="fab fa-instagram-square link"></i>
                       
                    </h5>
                </a>
                <a class="ml-3" href="https://es-la.facebook.com/me.quiero.graduar.ya/" target="_blank" class="" style="display:inline-block">
                   <h5 class="text-light">
                      <i class="fab fa-facebook-square link"></i>
                      
                   </h5>
                </a>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <h6 class="text-white mb-2"><i class="fas fa-envelope text-green" style=""></i> Correo:</h6>
                 <p id="email-footer-lg" class="text-light " style="color:rgb(217, 220, 221)">tulogroesnuestroexito2v@gmail.com</p>
                 <p id="email-footer-sm" class="text-light " style="color:rgb(217, 220, 221)">tulogroesnuestroexito2v <br>  @gmail.com</p>
                
            </div>
        </div>
    </div>
    <a href="https://www.sapienciaweb.com" target="_blank">
      <div id="footer-sap" class="mt-3">
        <h5 id="text-sap">Desarrollado por:</h5>
          <img id="logo-sap" src="<?php echo e(asset('public/images/default/sapiencia/logo-gold.png')); ?>" alt="">
          <img id="loetras-sap" src="<?php echo e(asset('public/images/default/sapiencia/letras.png')); ?>" alt="">
      </div>
    </a>
</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/front/layouts/footer.blade.php ENDPATH**/ ?>