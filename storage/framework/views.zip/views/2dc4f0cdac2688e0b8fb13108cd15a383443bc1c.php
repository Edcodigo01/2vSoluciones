<div class="bg- pt-5 site-footer" style="width:100%;background:linear-gradient(to bottom,rgb(38, 4, 88),rgb(18, 0, 43))">
    <div class="container2">
        <div class="row m-auto" style="width:100%">
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <h6 class="text-white"><i class="fas fa-map-marked-alt font600 " style=" !important"></i> Dirección:</h6>
                <p class="text- text-light"> Av. Mariana de Jesús y Jorge Juan N31-120, Quito - Ecuador</p>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <a href="https://api.Whatsapp.com/send?phone=+593989558833" class="whatsapp-mobile">
                    <h6 class="text-white"><i class="fab fa-whatsapp " style=""></i> WhatsApp:</h6>
                    <p class="text-light link" > +593989558833 </p>
                </a>
                <a href="https://web.Whatsapp.com/send?phone=593989558833&text=" class="whatsapp-web">
                    <h6 class="text-white"><i class="fab fa-whatsapp " style=""></i> WhatsApp:</h6>
                    <p class="text-light link" > +593989558833 </p>
                </a>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <h6 class="text-white mb-3"><i class="fas fa-users " style=""></i> Redes Sociales:</h6>
                <a href="https://www.instagram.com/2v_tesis/?hl=es-la" target="_blank" style="display:inline-block">
                    <h5 class="text-light">
                       <i class="fab fa-instagram-square link"></i>
                       
                    </h5>
                </a>
                <a class="ml-3" href="https://es-la.facebook.com/me.quiero.graduar.ya/" target="_blank" class="" style="display:inline-block">
                   <h5 class="text-light">
                      <i class="fab fa-facebook-square link"></i>
                      
                   </h5>
                </a>
                 <a class="ml-3" href="https://www.tiktok.com/@2v_tesis?lang=es" target="_blank" class="" style="display:inline-block">
                   <h5 class="text-light">
                      <i class="fab fa-tiktok link"></i>
                      
                   </h5>
                </a>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3 text-center">
                <h6 class="text-white mb-2"><i class="fas fa-envelope " style=""></i> Correo:</h6>
                 <p id="email-footer-lg" class="text-light " style="color:rgb(217, 220, 221)">tulogroesnuestroexito2v@gmail.com</p>
                 <p id="email-footer-sm" class="text-light " style="color:rgb(217, 220, 221)">tulogroesnuestroexito2v <br>  @gmail.com</p>
                
            </div>
        </div>
    </div>
    <a href="https://www.sapienciaweb.com" target="_blank">
      <div id="footer-sap" class="mt-3">
        <h5 id="text-sap">Desarrollado por:
          <img style="width:25px;height:auto" src="<?php echo e(asset('public/images/default/sapiencia/ico-sap.png')); ?>" alt="">Sapienciaweb.com</h5>
          
      </div>
    </a>
</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/front/layouts/footer.blade.php ENDPATH**/ ?>