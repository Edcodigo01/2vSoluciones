

<div class="modal" tabindex="-1" role="dialog" id="modalLogin">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-gradient">
        <h5 class="modal-title text-white" id="exampleModalLabel">Iniciar Sessión</h5>
        
      </div>
      <div class="modal-body">
        <div class="container">
          
          <form class="formula validate" action="<?php echo e(route('login')); ?>" method="post" id="form-login">

            <div class="form-group ">
              <label class=""for=""><i class="fas fa-user"></i> Usuari@</label>
              <input type="text"  class="form-control form-control-lg required" name="email" value="">
            </div>
            <div class="form-group">
              <label for=""><i class="fas fa-key"></i> Contraseña</label>
              <input type="text" class="form-control form-control-lg required password" name="password" value="">
            </div>
            <div class="form-group">
              <button type="submit" class="btn  bg-green btn-lg btn-block">Iniciar Sessión</button>
              <button type="button" class="btn btn-secondary btn-lg btn-block cancel">Cancelar</button>
            </div>

            
          </form>
          <br>
        </div>

      </div>

    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\2v\resources\views/front/home/modal/login.blade.php ENDPATH**/ ?>