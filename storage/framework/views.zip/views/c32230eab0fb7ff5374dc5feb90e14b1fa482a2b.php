<div class="navP">
   <div class="containerNav relative">
         <div style="float:left" class="zone-logo">

            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public\images\default\logos\logo-2v-sinfondo-trangular-sm.png')); ?>" alt="" class="logo-n"></a>
            
        </div>
         <div style="float:left" class="text-center linksN zone-links">
            <a href="<?php echo e(url('/')); ?>" class="linkN  <?php if(url('/') == url()->current()): ?> active <?php endif; ?>">Inicio</a>
            <a href="<?php echo e(url('servicios')); ?>" class="linkN  <?php if(url('servicios') == url()->current()): ?> active  <?php endif; ?>">Servicios</a>
            <a href="<?php echo e(url('nosotros')); ?>" class="linkN  <?php if(url('nosotros') == url()->current()): ?> active <?php endif; ?>">Nosotros</a>
               <a href="<?php echo e(url('testimonios')); ?>" class="linkN  <?php if(url('testimonios') == url()->current()): ?> active <?php endif; ?>">Testimonios</a>
            <a href="<?php echo e(url('videos')); ?>" class="linkN  <?php if(url('videos') == url()->current()): ?> active <?php endif; ?>">Videos</a>
               <a href="<?php echo e(url('articulos')); ?>" class="linkN  <?php if(url('articulos') == url()->current()): ?> active <?php endif; ?>">Artículos</a>
            <a href="<?php echo e(url('contactanos')); ?>" class="linkN  <?php if(url('contactanos') == url()->current()): ?> active <?php endif; ?>">Contáctanos</a>
         </div>
         <a type="button" name="button" class="float-right btn-main" style="font-size:30px"> <i class="fas fa-bars"></i> </a>
   </div>
</div>

<div class="navP navP2" style="display:">
   <div class="containerNav">
         <div style="float:left" class="zone-logo">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public\images\default\logos\logo-2v-sinfondo-trangular-sm.png')); ?>" alt="" class="logo-n"></a>

           
        </div>
         <div style="float:left" class="text-center linksN zone-links">
            <a href="<?php echo e(url('/')); ?>" class="linkN  <?php if(url('/') == url()->current()): ?> active <?php endif; ?>">Inicio</a>
            <a href="<?php echo e(url('servicios')); ?>" class="linkN  <?php if(url('servicios') == url()->current()): ?> active <?php endif; ?>">Servicios</a>
            <a href="<?php echo e(url('nosotros')); ?>" class="linkN  <?php if(url('nosotros') == url()->current()): ?> active <?php endif; ?>">Nosotros</a>
               <a href="<?php echo e(url('testimonios')); ?>" class="linkN  <?php if(url('testimonios') == url()->current()): ?> active <?php endif; ?>">Testimonios</a>
                  <a href="<?php echo e(url('videos')); ?>" class="linkN  <?php if(url('videos') == url()->current()): ?> active <?php endif; ?>">Videos</a>
            <a href="<?php echo e(url('articulos')); ?>" class="linkN  <?php if(url('articulos') == url()->current()): ?> active <?php endif; ?>">Artículos</a>
            <a href="<?php echo e(url('contactanos')); ?>" class="linkN  <?php if(url('contactanos') == url()->current()): ?> active <?php endif; ?>">Contáctanos</a>
         </div>
         <a type="button" name="button" class="float-right btn-main text-dark" style="font-size:30px;margin-top:-6px"> <i class="fas fa-bars"></i> </a>

   </div>
</div>

<div class="spaceNavbar">

</div>
<?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/resources/views/front/layouts/navbar.blade.php ENDPATH**/ ?>