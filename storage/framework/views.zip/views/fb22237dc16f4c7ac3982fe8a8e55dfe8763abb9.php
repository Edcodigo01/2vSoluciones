
<?php $__env->startSection("content"); ?>
    <div class="" id="scrollPaginate">

    </div>

    <div class="text-center paralax" style="background-image: url('public/images/default/servicios/trabajando.jpg');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">

            <span class="bg-green  px-3 py-2" style="display:inline-block">
                <h4 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-university"></i> Servicios Académicos</h4>
            </span>


        </div>
    </div>


    <!-- ##### Course Area Start ##### -->
    <div class="academy-courses-area mt-4 ">
        <div class="container2">
            <div class="row">
                <div class="col-12">
                    <h3 class="text- text-center"><i class="fas fa-university"></i> Servicios Académicos</h3>
                </div>
            </div>

            <div class="row mt-5">
                <!-- Single Course Area -->
                <div class="col-12 col-lg-4 wow fadeInUp" >

                    <a href="#">
                        <div class="single-course-area d-flex">
                            <div class="course-icon">
                                <img src="<?php echo e(asset('public/images/default/tesis.jpg')); ?>" alt="" class="image-icon">
                                
                            </div>
                            <div class="course-content">
                                <div class="text-center course-icon-mobile">
                                    <img src="<?php echo e(asset('public/images/default/tesis.jpg')); ?>" alt="" class="image-icon mb-4">
                                </div>
                                <h4 class="text-" >Proyectos de Fin de Grado</h4>
                                <p class="text-justify">Propuesta de tema, plan de tesis o anteproyecto, tesis de grado, tesinas, trabajos de fin de master (TFM), monografías, artículos científicos, complexivo, análisis y corrección de plagio, presentaciones,
                                    Correcciones de: contenido, redacción y sintaxis, metodología y normas.</p>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- Single Course Area -->
                    <div class="col-12 col-lg-4 wow fadeInUp" >
                        <a href="#">
                            <div class="single-course-area d-flex mb-50">
                                <div class="course-icon">
                                    
                                    <img src="<?php echo e(asset('public/images/default/deberes.jpg')); ?>" alt="" class="image-icon">

                                </div>
                                <div class="course-content">
                                    <div class="text-center course-icon-mobile">
                                        <img src="<?php echo e(asset('public/images/default/deberes.jpg')); ?>" alt="" class="image-icon mb-4">
                                    </div>
                                    <h4 class="text-"> Deberes Académicos</h4>
                                    <p class="text-justify">Ensayos, ejercicios prácticos, análisis, resúmenes, mapas mentales y conceptuales, cuestionarios, presentaciones, entre otros.</p>
                                    
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Single Course Area -->
                    <div class="col-12 col-lg-4 wow fadeInUp" >
                        <a href="#">
                            <div class="single-course-area d-flex mb-50">
                                <div class="course-icon">
                                    
                                    <img src="<?php echo e(asset('public/images/default/capacitacion.png')); ?>" alt="" class="image-icon">

                                </div>
                                <div class="course-content" style="width:100%">
                                    <div class="text-center course-icon-mobile">
                                        <img src="<?php echo e(asset('public/images/default/capacitacion.png')); ?>" alt="" class="image-icon mb-4">
                                    </div>
                                    <h4 class="text-">Capacitación</h4>
                                    <p class="text-justify">Defensa de tesis. <br>
                                        Clases online en diversas áreas.</p>

                                    </div>
                                </div>
                            </a>
                        </div>

                        <!-- Single Course Area -->
                        <div class="col-12 wow fadeInUp" >



                                    <div class="course-content text-center">
                                        <h4>Nuestro <span class="text-purple text-center">Plus</span> Académico:</h4>

                                            <p class="text-center">Te damos <span class="text-purple">acompañamiento</span> hasta que el proyecto sea <span class="text-purple">aprobado</span> por el tutor académico.</p>

                                            <p class="text-center">Manejamos <span class="text-purple">todos los niveles y modalidades </span> de estudios.</p>


                                             <p style="font-size:17px" class="font600"> <span class="text-purple">Más de 4 años de experiencia solo en Ecuador</span>, además tenemos clientes en:
                                                 <span class="text-purple">Colombia, México, Perú, Chile, Argentina y España.</span class="text-purples"></p>
                                    </div>


                                </div>

                            </div>
                        </div>
                    </div>

                    <div style="background-image:url('public/images/default/home/porque.png')" class="paralax">
                        <div class="filter" style="background:rgba(27, 27, 27, 0.14)">
                            <div class="container garantia">
                                <div class="row">
                                    <div class="col-12">

                                        <h2 class="text-white my-5 text-center wow fadeInUp">¿Por Qué Escogernos?</h2>

                                        <ul style="text-align:center" class="text-white wow fadeInLeft">
                                            <li><i class="fas fa-check"></i> Cientos de testimonios de clientes satisfechos en nuestro sitio web y redes sociales.</li>
                                            <li><i class="fas fa-check"></i> Equipo multidisciplinario altamente calificado, con amplia y sólida experiencia. </li>
                                            <li><i class="fas fa-check"></i> Honradez intelectual.</li>
                                            <li><i class="fas fa-check"></i> Antiplagio.</li>
                                            <li><i class="fas fa-check"></i> Trabajos garantizados.</li>
                                            <li><i class="fas fa-check"></i> Cumplimiento de las normas establecidas por la casa de estudios.</li>
                                            <li><i class="fas fa-check"></i> Tiempos de respuestas oportunos.</li>
                                            <li><i class="fas fa-check"></i> Responsabilidad.</li>
                                            <li><i class="fas fa-check"></i> Compromiso.</li>


                                            <li><i class="fas fa-check"></i> Asesoría constante.</li>
                                            <li><i class="fas fa-check"></i> Nuestro Compromiso: garantizar tu éxito y sumar clientes satisfechos. </li>
                                        </ul>
                                        <br>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/servicios/serviciosA.blade.php ENDPATH**/ ?>