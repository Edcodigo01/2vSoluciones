
<?php $__env->startSection("content"); ?>
    <div class="" id="scrollPaginate">

    </div>
    <div class="text-center paralax" style="background-image: url('public/images/default/servicios/trabajando.jpg');">
        <div class="padding-title" style="background:rgba(36, 35, 35, 0.38)">
            <span class="bg-green px-3 py-2" style="display:inline-block">
                <h4 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-user-tie"></i> Servicios Empresariales</h4>
            </span>
        </div>
    </div>


    <!-- ##### Course Area Start 2##### -->
<div class="academy-courses-area" style="background:rgb(231, 231, 231)">
<div class="container2">

    <div class="row">
        <div class="col-12">
            <br>
            <h3 class="text- text-center"><i class="fas fa-user-tie"></i> Servicios Empresariales</h3>
        </div>
    </div>
    <div class="row mt-5">


        <!-- Single Course Area -->
        <div class="col-12 col-lg-4 wow fadeInUp" >
            <a href="#">
                <div class="single-course-area d-flex mb-50">
                    <div class="course-icon">
                        
                        <img src="<?php echo e(asset('public\images\default\servicios\org.jpg')); ?>" alt="" class="image-icon">

                    </div>
                    <div class="course-content" style="width:100%">
                        <div class="text-center course-icon-mobile">
                            <img src="<?php echo e(asset('public\images\default\servicios\org.jpg')); ?>" alt="" class="image-icon mb-4">
                        </div>
                        <h4 class="text-" >Mejoramiento Organizacional</h4>

                        <ul class="mt-2" style="font-weight:500;color:rgb(57, 57, 57)">
                            <li> <i class="far fa-circle text-purple"></i>  Filosofía de gestión.  </li>
                            <li> <i class="far fa-circle text-purple"></i>  Reglamento interno de trabajo.  </li>
                            <li> <i class="far fa-circle text-purple"></i>  Estructura organizativa.  </li>
                            <li> <i class="far fa-circle text-purple"></i>  Descripción de cargos.  </li>
                            <li> <i class="far fa-circle text-purple"></i>  Normas y proceso.s </li>
                            <li> <i class="far fa-circle text-purple"></i>  Formularios e Instructivos de control interno.  </li>
                            <li> <i class="far fa-circle text-purple"></i>  Subsistemas de talento humano. </li>
                            <li> <i class="far fa-circle text-purple"></i>  Capacitación gerencial y de equipo de trabajo.  </li>
                        </ul>

                        </div>
                    </div>
                </a>
            </div>

            <!-- Single Course Area -->
            <div class="col-12 col-lg-4 wow fadeInUp" >
                <a href="#">
                    <div class="single-course-area d-flex mb-50">
                        <div class="course-icon">
                            
                            <img src="<?php echo e(asset('public\images\default\servicios\marketing.jpg')); ?>" alt="" class="image-icon">

                        </div>
                        <div class="course-content" style="width:100%">
                            <div class="text-center course-icon-mobile">
                                <img src="<?php echo e(asset('public\images\default\servicios\marketing.jpg')); ?>" alt="" class="image-icon mb-4">
                            </div>
                            <h4 class="text-">Marketing </h4>

                            <ul class="mt-2" style="font-weight:500;color:rgb(57, 57, 57)">
                                <li> <i class="far fa-circle text-purple"></i> Imagen corporativa.  </li>
                                <li> <i class="far fa-circle text-purple"></i> Creación de contenidos.  </li>
                                <li> <i class="far fa-circle text-purple"></i> Edición de recursos fotográficos .  </li>
                                <li> <i class="far fa-circle text-purple"></i> Capacitación posicionamiento redes sociales  . </li>

                            </ul>

                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-12 col-lg-4 wow fadeInUp" >
                    <a href="#">
                        <div class="single-course-area d-flex mb-50">
                            <div class="course-icon">
                                
                                <img src="<?php echo e(asset('public\images\default\servicios\sitio web.png')); ?>" alt="" class="image-icon">

                            </div>
                            <div class="course-content">
                                <div class="text-center course-icon-mobile">
                                    <img src="<?php echo e(asset('public\images\default\servicios\sitio web.png')); ?>" alt="" class="image-icon mb-4">
                                </div>
                                <h4 class="text-"> Sitios web </h4>
                                <ul class="mt-2" style="font-weight:500;color:rgb(57, 57, 57)">
                                    <li> <i class="far fa-circle text-purple"></i> Diseño y desarrollo de sitios web.  </li>
                                    <li> <i class="far fa-circle text-purple"></i> Desarrollo de aplicaciones y otros.  </li>

                                </ul>
                                
                            </div>
                        </div>
                    </a>
                </div>
                <!-- Single Course Area -->
                <!-- Single Course Area -->
                <div class="col-12 wow fadeInUp mt-4" >

                    <div class="single-course-area d-flex mb-50 text-center">

                        <div class="course-content text-center m-auto">
                            <h4>Nuestro <span class="text-purple text-center">Plus</span> Empresarial:</h4>

                            <p class="text-center">Te damos <span class="text-purple">acompañamiento</span> hasta que <span class="text-purple"> tu negocio esté en marcha. </span> </p>

                        </div>
                    </div>

                </div>

                    </div>
                </div>
            </div>

                    <div style="background-image:url('public/images/default/home/porque.png')" class="paralax">
                        <div class="filter" style="background:rgba(27, 27, 27, 0.14)">
                            <div class="container garantia">
                                <div class="row">
                                    <div class="col-12">

                                        <h2 class="text-white my-5 text-center wow fadeInUp">¿Por Qué Escogernos?</h2>

                                        <ul style="text-align:center" class="text-white wow fadeInLeft">
                                            <li><i class="fas fa-check"></i> Cientos de testimonios de clientes satisfechos en nuestro sitio web y redes sociales.</li>
                                            <li><i class="fas fa-check"></i> Equipo multidisciplinario altamente calificado, con amplia y sólida experiencia. </li>
                                            <li><i class="fas fa-check"></i> Honradez intelectual.</li>
                                            <li><i class="fas fa-check"></i> Antiplagio.</li>
                                            <li><i class="fas fa-check"></i> Trabajos garantizados.</li>
                                            <li><i class="fas fa-check"></i> Cumplimiento de las normas establecidas por la casa de estudios.</li>
                                            <li><i class="fas fa-check"></i> Tiempos de respuestas oportunos.</li>
                                            <li><i class="fas fa-check"></i> Responsabilidad.</li>
                                            <li><i class="fas fa-check"></i> Compromiso.</li>


                                            <li><i class="fas fa-check"></i> Asesoría constante.</li>
                                            <li><i class="fas fa-check"></i> Nuestro Compromiso: garantizar tu éxito y sumar clientes satisfechos. </li>
                                        </ul>
                                        <br>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/servicios/serviciosEmp.blade.php ENDPATH**/ ?>