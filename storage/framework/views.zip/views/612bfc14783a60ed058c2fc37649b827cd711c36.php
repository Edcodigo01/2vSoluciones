<div id="" class="carousel slide" data-ride="carousel" data-interval="2500" data-pause="false">
    <div class="text-centered textSlider wow fadeInUp">
        <br>
        <br>
        <br>
        <h3 style="font-size:50px;z-index:999;color:rgb(250, 4, 255)" data-animation="fadeInUp" ><span class="bg-tr py-1 px-2" >2V Soluciones Académicas & Empresariales.</span></h3>
        <br>

        <h3 style="z-index:999" class="text-green mr-5 bg-tr"  data-animation="fadeInUp" ><span class="text-green bg-tr py-1 px-2" >Tesis, deberes académicos y más… </span></h3>
        <br>
        <h4 style="z-index:999" class="mt-2 text-white bg-tr" data-animation="fadeInUp" ><span class="text-white bg-tr2 py-1 px-2" >¡Tu logro es nuestro éxito! </span></h4>
    </div>
    <div class="carousel-inner" >
        <div class="carousel-item active" style="position:relative">
            <div class="obscure">

            </div>
          <img src="<?php echo e(asset('public/images/sliderHome/2.png')); ?>" class="d-block w-100 img-slider" alt="..." style="object-fit:cover;width:100%;height:100%;">
        </div>
        <div class="carousel-item " style="position:relative">
            <div class="obscure">

            </div>
          <img src="<?php echo e(asset('public/images/sliderHome/1.png')); ?>" class="d-block w-100 img-slider" alt="..." style="object-fit:cover;width:100%;height:100%">
        </div>

      <div class="carousel-item " style="position:relative">
          <div class="obscure">

          </div>
        <img src="<?php echo e(asset('public/images/sliderHome/3.jpg')); ?>" class="d-block w-100 img-slider" alt="..." style="object-fit:cover;width:100%;height:100%">
      </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/front/home/slider.blade.php ENDPATH**/ ?>