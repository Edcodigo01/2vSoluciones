<!-- Modal -->
<div class="modal fade" id="modalDisabled" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h4 class="modal-title text-white" id="exampleModalLabel"><i class="fas fa-exclamation-triangle mr-2"></i>Atención</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-warning">¿Estas segur@ de deshabilitar este árticulo?</h5>
            </div>
            <div class="modal-footer">
                <form action="" class="formula" method="POST" id="form-disabled">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-times"></i> Cancelar</button>
                    <button class="btn btn-warning" name="button"><i class="fas fa-exclamation-triangle"></i> Aceptar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/articles/includes/modalDisabled.blade.php ENDPATH**/ ?>