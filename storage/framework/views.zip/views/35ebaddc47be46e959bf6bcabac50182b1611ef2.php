<footer class="bg-dark pt-5 site-footer" style="">
    <div class="container2">

        <div class="row">
            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <h6 class="text-white"><i class="fas fa-map-marked-alt font600" style="font-size:30px !important"></i> Dirección:</h6>
                <p class="text-justify text-light"> Av. Mariana de Jesús y Jorge Juan N31-120, Quito - Ecuador</p>
            </div>

            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <a href="https://api.whatsapp.com/send?phone=+593989558833" class="whatsapp-mobile">
                    <h6 class="text-white"><i class="fab fa-whatsapp-square " style="font-size:37px !important"></i> Whatsapp:</h6>
                    <p class="text-light" > +593989558833 </p>
                </a>
                <a href="https://web.whatsapp.com/send?phone=593989558833&text=" class="whatsapp-web">
                    <h6 class="text-white"><i class="fab fa-whatsapp-square " style="font-size:37px !important"></i> Whatsapp:</h6>
                    <p class="text-light" > +593989558833 </p>
                </a>
            </div>

            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <h6 class="text-white mb-3"><i class="fas fa-users " style=""></i> Redes Sociales:</h6>

                <a href="https://www.instagram.com/2v_tesis/?hl=es-la" target="_blank" style="display:inline-block">
                    <h6 class="text-light">
                        <i class="fab fa-instagram-square " style="font-size:35px;margin-top:-30px"></i>
                    </h6>
                </a>

                <a class="ml-3" href="https://es-la.facebook.com/me.quiero.graduar.ya/" target="_blank" class="" style="display:inline-block">
                    <h6 class="text-light">
                        <i class="fab fa-facebook-square " style="font-size:35px;margin-top:-30px"></i>
                    </h6>
                </a>
            </div>
            <div class="col-12 col-lg-6 mb-3 col-xl-3">
                <h6 class="text-white mb-2"><i class="fas fa-envelope " style="font-size:30px !important"></i> Correo:</h6>

                <p class="text-light">
                 <span class="text-light" style="color:rgb(217, 220, 221)">tulogroesnuestroexito2v@gmail.com</span>
              </p>
                
            </div>

        </div>
    </div>

</footer>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/layouts/footer.blade.php ENDPATH**/ ?>