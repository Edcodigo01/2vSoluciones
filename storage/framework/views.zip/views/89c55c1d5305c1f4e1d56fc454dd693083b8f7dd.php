<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="<?php echo e(asset("public/libraries/css/template.css")); ?>">
  <?php echo $__env->make("layouts.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent("styles"); ?>
</head>

<body style="background:rgba(246, 255, 240, 1)">
        <?php echo $__env->make("layouts.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="height:120px" class="bg-gradient">

        </div>

        <?php echo $__env->make("layouts.fixedSocial", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("layouts.loader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent("content"); ?>
        <?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <input type="hidden" name="" value="<?php echo e(url('/')); ?>" id="url_base">

        <?php echo $__env->make("layouts.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent("scripts"); ?>
        <script src="<?php echo e(asset('public/js/blog.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/layouts/index.blade.php ENDPATH**/ ?>