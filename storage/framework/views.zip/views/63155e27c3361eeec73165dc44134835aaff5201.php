
<?php $__env->startSection('title'); ?>
  2V-Admin-Videos
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="" id="scrollPaginate">

    </div>
    <div class="row">
        <div class="col-12">
            <button type="button" name="button" class="btn bg-purple float-right mt-4" onclick="showModal('#modalCreate','#uploadVideo')"><i class="fas fa-plus"></i> Nuevo</button>
            <h2 class="mb-4 text-green">Videos</h2>
        </div>
    </div>

    <div class="container mt-4">
        <div class="viewAjax" data-route="<?php echo e(route('list_videos')); ?>">


            <?php if($videos->first() == null): ?>
                <h3 class="text-warning text-center mt-5"><span class="text-" style="font-size:30px"><i class="fas fa-exclamation-triangle"></i></span> No ahy videos registrados</h3>
            <?php else: ?>

                    <h5 style="display:none" class="showSearch">Busqueda: <span class="text-secondary textShowSearch"></span></h5>
                        <div class="row">
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-6 col-md-4 mb-4" style="z-index:2000px">
                                        <div class="card contentInput" style="height:100%">


                                            <div class="card-header bg-green" style="min-height:60px;display:flex;align-items: center;">
                                                <p class="text-white font600 text-center" style="line-height:18px;margin:auto;"><?php echo $video->title; ?></p>

                                            </div>
                                            <div class="card-body disabled logoContent p-1 playVideo bg-green" style="position: relative">
                                                <input type="hidden" name="" value="<?php echo e($video->title); ?>" class="title">
                                                <input type="hidden" name="" value="<?php echo e($video->url); ?>" class="url">
                                                <input type="hidden" name="" value="<?php echo e($video->description); ?>" class="description">
                                                <input type="hidden" name="" value="<?php echo e($video->id); ?>" class="vide_id">
                                                <div class="logo-play" style="">
                                                    <i class=" fas fa-play text-white" style="font-size:65px;margin:auto;"></i>
                                                </div>

                                                    <img src="<?php echo e('https://img.youtube.com/vi/'.$video->url.'/0.jpg'); ?>" alt="" style="width:100%;height:100%">


                                            </div>
                                            <div class="card-footer mt-4">
                                                
                                                <button onclick="modalDeleteAJAX(<?php echo e($video->id); ?>)" class="btn bg-danger btn-sm" style="position:absolute;bottom:5px;right:90px;"><i class="fas fa-times"></i> Eliminar</button>
                                                <button  class="btn bg-green btn-sm" onclick="showModalEdit(this)" style="position:absolute;bottom:5px;right:10px;"><i class="fas fa-edit"></i> Editar  </button>
                                            </div>


                                        </div>
                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <?php if($videos->lastPage() != 1): ?>
                        <div class="card-footer bg-gradient font600 mb-4 p-3">
                            <span class="pagination float-right"><?php echo e($videos->links()); ?></span>

                            <input type="hidden" name="" value="<?php echo e($videos->currentPage()); ?>" class="form-control" id="numberPage">
                            <h5 class="text-white">Página Nro. <?php echo e($videos->currentPage()); ?> de
                            <?php echo e($videos->lastPage()); ?></h5>

                        </div>
                        <?php endif; ?>
                <?php endif; ?>

            </div>
    </div>

        <input type="hidden" name="" value="<?php echo e(url()->current()); ?>" id="urlNow">
        <input type="hidden" name="" value="" id="urlNow">
    <?php echo $__env->make('videos.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('videos.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.modalsGlobal.modalVideoFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('videos.includes.modalDeleteAJAX', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    $(document).on("click", ".pagination a", function(e){
        e.preventDefault();
        showLoader();
        var url = $(this).attr('href');
        if(!url.includes('list_videos')){
            url = url.replace('administrar-videos','list_videos');
        }
        viewAjax('.viewAjax',url);

        $('html, body').animate({
            scrollTop: $("#scrollPaginate").offset().top
        }, 500);

    });

    function showModalEdit(btn){
        card = $(btn).parents('.contentInput');
        title = $(card).find('.title').val();
        url = $(card).find('.url').val();
        url = 'https://www.youtube.com/watch?v='+url;
        // url = url.replace('embed/','watch?v=');
        description = $(card).find('.description').val();
        id = $(card).find('.vide_id').val();
        $('#title').val(title);
        $('#url').val(url);
        $('#description').val(description);
        $('#update_ajax').attr('action','administrar-videos/'+id);
        $('#modalEdit').modal('show');
    }



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/videos/videos.blade.php ENDPATH**/ ?>