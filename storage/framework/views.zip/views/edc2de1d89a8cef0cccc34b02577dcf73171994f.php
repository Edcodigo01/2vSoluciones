
  <nav class="navbar navbar-expand-lg navbar-light bg-light bg-gradient fixed-top" style="padding:15px">
    <a class="navbar-brand" href="#" style="padding:0px">
      <img class="logo-g" src="<?php echo e(asset("public\images\default\logo.jpg")); ?>" alt="" style="margin:0">
      <img class="logo-p" src="<?php echo e(asset("public\images\default\logo-sm.jpg")); ?>" alt="" style="display:none" style="margin:0">

    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav mt-2 mt-lg-0" style="margin:auto;">
        <li class="nav-item">
          <a class="btn btn-outline-light ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'home')): ?> active <?php endif; ?>" href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i> Incio <span class="sr-only">(current)</span></a>
        </li>

        <li class="dropdown nav-item">

          <a class="btn btn-outline-light ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'serviciosEmp')): ?> active <?php endif; ?> <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'serviciosA')): ?> active <?php endif; ?>"><i class="fas fa-list"></i>   Servicios <i class="fa fa-chevron-down"></i></a>
          <div class="dropdown-content bg-secondary">

              <a class="dropdown-item text-white font600" href="<?php echo e(url('servicios-academicos')); ?>"><i class="fas fa-university"></i> Académicos</a>
              <a class="dropdown-item text-white font600" href="<?php echo e(url('servicios-empresariales')); ?>"><i class="fas fa-user-tie"></i> Empresariales</a>
          </div>
        </li>
        <li class="nav-item active">
          <a class="btn btn-outline-light  ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'somos')): ?> active <?php endif; ?>" href="<?php echo e(route('somos')); ?>"><i class="fas fa-users"></i> Quiénes somos</a>
        </li>
        <li class="dropdown nav-item">
          <a href="<?php echo e(route('articles')); ?>" class="btn btn-outline-light ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'articles')): ?> active <?php endif; ?>"><i class="fas fa-book-open"></i> Artículos de Interés <i class="fa fa-chevron-down"></i></a>
          <div class="dropdown-content bg-secondary">

              <?php $__currentLoopData = Categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($value->articles->count() != 0): ?>
                      <a class="dropdown-item text-white font600" href="<?php echo e(url('articulos?categoria='.$value->name)); ?>"> <i class="fas fa-check ml-1"></i> <?php echo e($value->name); ?></a>
                  <?php endif; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <a class="dropdown-item text-white font600" href="<?php echo e(route('articles')); ?>"><i class="fas fa-list ml-1"></i> Todos</a>
          </div>
        </li>
        <li class="nav-item active">
          <a class="btn btn-outline-light  ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'testimonios')): ?> active <?php endif; ?>" href="<?php echo e(route('testimonios')); ?>"><i class="fas fa-comments"></i> Testimonios</a>
        </li>
        <?php if (\Illuminate\Support\Facades\Blade::check('Videos')): ?>
        <li class="nav-item active">
          <a class="btn btn-outline-light  ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'videos')): ?> active <?php endif; ?>" href="<?php echo e(route('videos')); ?>"><i class="fas fa-video"></i>  Videos</a>
        </li>
        <?php endif; ?>

        <li class="nav-item active">
          <a class="btn btn-outline-light  ml-2 font600 <?php if (\Illuminate\Support\Facades\Blade::check('Route', 'contactanos')): ?> active <?php endif; ?>" href="<?php echo e(route('contactanos')); ?>"><i class="fas fa-phone-alt text-white"></i>  Contáctanos</a>
        </li>
      </ul>
      
      
    </div>
  </nav>

  

<?php /**PATH C:\xampp\htdocs\2v\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>