
<?php $__env->startSection('title'); ?>
    2V-Panel-Administración
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

    <div class="container mt-4 p-2">
            <div class="card">
                <div class="card-header bg-gradient">
                    <h2 class="text-white">Panel de Administración</h2>
                </div>
                <div class="card-body" style="background:rgb(235, 223, 234)">
                    <div class=" row text-center">
                        <div class="col-md-3">

                        </div>
                        <div class="col-md-3 m-4" >
                            <div class="card bg-purple" style="height:100%">

                                    <div class="card-body" style="display:flex;align-items:center;justify-content: center;">

                                        <a href="<?php echo e(route('administrar-articulos.index')); ?>" class="btn btn-lg btn-block bg-green"><i class="fas fa-book-open text-white"></i> Artículos</a>

                                        <ul class="text-left mt-4" style="line-height:30px">
                                            <li class="text-green"><a class="btn btn-sm bg-green text-white" href="<?php echo e(route('administrar-categorias.index')); ?>">Categorías</a> </li>

                                            <li class="text-green mt-2"><a class="btn bg-green text-white btn-sm" href="<?php echo e(route('administrar-etiquetas.index')); ?>">Etiquetas</a> </li>


                                        </ul>
                                    </div>
                            </div>
                        </div>

                        <div class="col-md-3 m-4" >
                            <div class="card bg-purple" style="height:100%;">

                                    <div class="card-body" style="display:flex;align-items:center;justify-content: center;">

                                        <a href="<?php echo e(route('administrar-videos.index')); ?>" class="btn btn-lg btn-block bg-green"><i class="fas fa-video text-white"></i> Videos</a>


                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/admin/panelAdmin.blade.php ENDPATH**/ ?>