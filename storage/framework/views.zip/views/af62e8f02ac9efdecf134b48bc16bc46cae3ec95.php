
<?php $__env->startSection('title'); ?>
  2V-Admin-Videos
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="" id="scrollPaginate">

    </div>
    <div class="row">
        <div class="col-12">
            <button type="button" name="button" class="btn btn-primary float-right mt-4" onclick="showModal('#modalCreate','#uploadVideo')"><i class="fas fa-plus"></i> Nuevo</button>
            <h2 class="mb-4 text-">Videos</h2>
        </div>
    </div>

    <div class=" mt-4">
        <div class="viewAjax" data-route="<?php echo e(route('list_videos')); ?>">
            <?php echo $__env->make('videos.videos_ajax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>
    </div>

        <input type="hidden" name="" value="<?php echo e(url()->current()); ?>" id="urlNow">
        <input type="hidden" name="" value="" id="urlNow">
    <?php echo $__env->make('videos.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('videos.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.modalsGlobal.modalVideoFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('videos.includes.modalDeleteAJAX', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    $(document).on("click", ".pagination a", function(e){
        e.preventDefault();
        showLoader();
        var url = $(this).attr('href');
        if(!url.includes('list_videos')){
            url = url.replace('administrar-videos','list_videos');
        }
        viewAjax('.viewAjax',url);

        $('html, body').animate({
            scrollTop: $("#scrollPaginate").offset().top
        }, 500);

    });

    function showModalEdit(btn){
        card = $(btn).parents('.contentInput');
        title = $(card).find('.title').val();
        url = $(card).find('.url').val();
        url = 'https://www.youtube.com/watch?v='+url;
        // url = url.replace('embed/','watch?v=');
        description = $(card).find('.description').val();
        id = $(card).find('.vide_id').val();
        $('#title').val(title);
        $('#url').val(url);
        $('#description').val(description);
        $('#update_ajax').attr('action','administrar-videos/'+id);
        $('#modalEdit').modal('show');
    }



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2vR\resources\views/videos/videos.blade.php ENDPATH**/ ?>