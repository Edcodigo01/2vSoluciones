<h1 class="">Esrta es la vista bienvenida</h1>
<h1 class="">Esrta es la vista bienvenida</h1>
<h1 class="">Esrta es la vista bienvenida</h1>
<h1 class="">Esrta es la vista bienvenida</h1>
<h1 class="">Esrta es la vista bienvenida</h1>
<h1 class="">Esrta es la vista bienvenida</h1>
<h1 class="">Esrta es la vista bienvenida</h1>
<?php /**PATH C:\xampp\htdocs\2v\resources\views/welcome.blade.php ENDPATH**/ ?>