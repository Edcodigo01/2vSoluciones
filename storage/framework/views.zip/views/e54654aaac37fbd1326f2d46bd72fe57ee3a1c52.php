

<?php $__env->startSection("content"); ?>
   <div class="text-center paralax" style="background-image: url('public/images/default/servicios/trabajando.jpg');">
      <div class="container-title" style="background:rgba(36, 35, 35, 0.38)">
           <span class="bg-green px-3 py-2" style="display:inline-block">
               <h4 class="text-center text-white mt-1 titleArticle" ><i class="fas fa-user-tie"></i> Servicios</h4>
           </span>
      </div>
   </div>
<?php echo $__env->make('front.servicios.contentServices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("front.layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2vR\resources\views/front/servicios/serviciosEmp.blade.php ENDPATH**/ ?>