<div class="row" id="artilces-mobile">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
          <input type="hidden" name="" value="<?php echo e($numberA = 0); ?>" class="form-control " >
          <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="hidden" name="" value="<?php echo e($numberA = $numberA + 1); ?>" class="form-control " >
              <a href="<?php echo e(route('article',$article->slug)); ?>">
              <div class="carousel-item <?php if($numberA == 1): ?>active <?php endif; ?> container">

                      <div class="card wow fadeInLeft" style="height:100%;" data-wow-delay="">
                          <div class="card-header">
                              <img style="object-fit:cover;border:solid 1px rgb(181, 178, 182);height:150px;width:100%" class="popular-course-thumb bg-img" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                          </div>
                          <div class="card-body">
                              <div class="mb-3" style="max-height:150px;overflow:hidden;">
                                  <h6 class="text-center text-purple"><?php echo $article->title; ?></h6>
                                  <div class="row">
                                      <div class="col-12">
                                          <span class="" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></span>
                                          <span class="float-right text-dark" style="font-size:11px"><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></span>
                                      </div>
                                  </div>
                              </div>

                              <a href="<?php echo e(route('article',$article->slug)); ?>" class="btn bg-green btn-sm float-right" style="position:absolute;bottom:5px;right:10px;">Leer <i class="fas fa-arrow-right"></i> </a>
                          </div>
                      </div>

              </div>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



      </div>
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon " aria-hidden="true"></span>
        <span class="sr-only">Anterior</span>
      </a>
      <a class="carousel-control-next text-danger" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Siguiente</span>
      </a>
    </div>

    <div class="text-center">
        <a style="" href="<?php echo e(route('articles')); ?>" class="btn academy-btn btn mt-4">Más Artículos <i class="fas fa-arrow-right"></i></a>
    </div>
</div>


<div class="row" id="artilces-lg">


    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="col-sm-6 col-lg-4 col-xl-3 mb-4">
            <a href="<?php echo e(route('article',$article->id)); ?>">
            <div class="card wow fadeInLeft border-g" style="height:100%;" data-wow-delay="">
                <div class="card-header p-1 border-g">
                    <img style="object-fit:cover;border:solid 1px rgb(181, 178, 182);height:150px;width:100%" class="popular-course-thumb bg-img" src="<?php echo e(asset($article->imageP)); ?>" alt="">
                </div>
                <div class="card-body border-g">
                    <div class="mb-3" style="max-height:150px;overflow:hidden;">
                        <h6 class="text-center text-purple"><?php echo $article->title; ?></h6>
                        <div class="row">
                            <div class="col-12">
                                <span class="" style="font-size:11px"><span class="font600">Autor:</span> <?php echo $article->autor; ?></span>
                                <span class="float-right text-dark" style="font-size:11px"><?php echo Carbon\Carbon::parse($article->created_at)->format('d-m-Y'); ?></span>
                            </div>
                        </div>
                    </div>

                    <button  class="btn bg-green btn-sm m-auto" style="position:absolute;bottom:5px;right:10px;">Leer <i class="fas fa-arrow-right"></i> </button>
                </div>
            </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 my-4 text-center">
        <a href="<?php echo e(route('articles')); ?>" class="btn academy-btn btn">Más Artículos <i class="fas fa-arrow-right"></i></a>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\2v\resources\views/front/home/includes/articles.blade.php ENDPATH**/ ?>