
<?php $__env->startSection('title'); ?>
  2V-Correos-Recibidos
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <h2 class="mb-4 text-green">Correos Recibidos</h2>

    <table class="listar table table-bordered table-striped listar" data-route="list_emailsrecibidos" data-update="emails-recibidos/{id}" data-delete="emails-recibidos/{id}" id="table-emails-received">

    <thead>
      <tr>
        <th>Id</th>
        <th>Correo Usuario</th>
        <th>Whatsapp </th>
        <th>Asunto </th>
        <th>Mensaje </th>
        <th>Enviado </th>
        <th>Error </th>

      </tr>
    </thead>
    <tbody>

    </tbody>
    </table>

    <?php echo $__env->make('category.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input type="hidden" name="" value="<?php echo e($Messagescontact); ?>" id="data">
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2vR\resources\views/admin/emailsReceived/emailsReceived.blade.php ENDPATH**/ ?>