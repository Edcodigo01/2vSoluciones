<div class="modal fade" id="modalEnable" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-success">
        <h2 class="modal-title" id="exampleModalLongTitle" ><i class="fas fa-exclamation-triangle"></i> !Atencion¡</h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form class="formula" action="" method="post" id="formEnable">
        <div class="modal-body">
            <h3 class="text-success"> ¿Estas segur@ de habilitar estos datos? </h3>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-times-circle"></i> Close</button>
          <button type="submit" class="btn btn-success"><i class="fas fa-check"></i> Aceptar</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\2v\resources\views/articles/includes/modalEnable.blade.php ENDPATH**/ ?>