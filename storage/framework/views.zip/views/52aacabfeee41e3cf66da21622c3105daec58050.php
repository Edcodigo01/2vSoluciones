
<?php $__env->startSection("content"); ?>
    <?php echo $__env->make('front.home.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Course Area Start ##### -->
    <div class="academy-courses-area mt-4 ">
        <div class="container2">
            <div class="row">
                <div class="col-12">
                    <h3 class="text- text-center"><i class="fas fa-university"></i> Servicios Académicos</h3>
                </div>
            </div>

            <div class="row mt-5">
                <!-- Single Course Area -->
                <div class="col-12 col-lg-4 wow fadeInUp" >

                    <a href="#">
                        <div class="single-course-area d-flex">
                            <div class="course-icon">
                                <img src="<?php echo e(asset('public/images/default/tesis.jpg')); ?>" alt="" class="image-icon">
                                
                            </div>
                            <div class="course-content">
                                <div class="text-center course-icon-mobile">
                                    <img src="<?php echo e(asset('public/images/default/tesis.jpg')); ?>" alt="" class="image-icon mb-4">
                                </div>
                                <h4 class="text-" >Proyectos de Fin de Grado</h4>
                                <p class="text-justify">Propuesta de tema, plan de tesis o anteproyecto, tesis de grado, tesinas, trabajos de fin de master (TFM), monografías, artículos científicos, complexivo, análisis y corrección de plagio, presentaciones,
                                    Correcciones de: contenido, redacción y sintaxis, metodología y normas.</p>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- Single Course Area -->
                    <div class="col-12 col-lg-4 wow fadeInUp" >
                        <a href="#">
                            <div class="single-course-area d-flex mb-50">
                                <div class="course-icon">
                                    
                                    <img src="<?php echo e(asset('public/images/default/deberes.jpg')); ?>" alt="" class="image-icon">

                                </div>
                                <div class="course-content">
                                    <div class="text-center course-icon-mobile">
                                        <img src="<?php echo e(asset('public/images/default/deberes.jpg')); ?>" alt="" class="image-icon mb-4">
                                    </div>
                                    <h4 class="text-"> Deberes Académicos</h4>
                                    <p class="text-justify">Ensayos, ejercicios prácticos, análisis, resúmenes, mapas mentales y conceptuales, cuestionarios, presentaciones, entre otros.</p>
                                    
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Single Course Area -->
                    <div class="col-12 col-lg-4 wow fadeInUp" >
                        <a href="#">
                            <div class="single-course-area d-flex mb-50">
                                <div class="course-icon">
                                    
                                    <img src="<?php echo e(asset('public/images/default/capacitacion.png')); ?>" alt="" class="image-icon">

                                </div>
                                <div class="course-content" style="width:100%">
                                    <div class="text-center course-icon-mobile">
                                        <img src="<?php echo e(asset('public/images/default/capacitacion.png')); ?>" alt="" class="image-icon mb-4">
                                    </div>
                                    <h4 class="text-">Capacitación</h4>
                                    <p class="text-justify">Defensa de tesis. <br>
                                        Clases online en diversas áreas.</p>

                                    </div>
                                </div>
                            </a>
                        </div>

                        <!-- Single Course Area -->
                        <div class="col-12 wow fadeInUp" >



                                    <div class="course-content text-center">
                                        <h4>Nuestro <span class="text-purple text-center">Plus</span> Académico:</h4>

                                            <p class="text-center">Te damos <span class="text-purple">acompañamiento</span> hasta que el proyecto sea <span class="text-purple">aprobado</span> por el tutor académico.</p>

                                            <p class="text-center">Manejamos <span class="text-purple">todos los niveles y modalidades </span> de estudios.</p>


                                             <p style="font-size:17px" class="font600"> <span class="text-purple">Más de 4 años de experiencia solo en Ecuador</span>, además tenemos clientes en:
                                                 <span class="text-purple">Colombia, México, Perú, Chile, Argentina y España.</span class="text-purples"></p>
                                    </div>


                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- ##### Course Area End ##### -->


                    <!-- ##### Course Area Start 2##### -->
            <div class="academy-courses-area" style="background:rgb(231, 231, 231)">
                <div class="container2">

                    <div class="row">
                        <div class="col-12">
                            <br>
                            <h3 class="text- text-center"><i class="fas fa-user-tie"></i> Servicios Empresariales</h3>
                        </div>
                    </div>
                    <div class="row mt-5">


                        <!-- Single Course Area -->
                        <div class="col-12 col-lg-4 wow fadeInUp" >
                            <a href="#">
                                <div class="single-course-area d-flex mb-50">
                                    <div class="course-icon">
                                        
                                        <img src="<?php echo e(asset('public\images\default\servicios\org.jpg')); ?>" alt="" class="image-icon">

                                    </div>
                                    <div class="course-content" style="width:100%">
                                        <div class="text-center course-icon-mobile">
                                            <img src="<?php echo e(asset('public\images\default\servicios\org.jpg')); ?>" alt="" class="image-icon mb-4">
                                        </div>
                                        <h4 class="text-" >Mejoramiento Organizacional</h4>

                                        <ul class="mt-2" style="font-weight:500;color:rgb(57, 57, 57)">
                                            <li> <i class="far fa-circle text-purple"></i>  Filosofía de gestión.  </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Reglamento interno de trabajo.  </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Estructura organizativa.  </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Descripción de cargos.  </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Normas y proceso.s </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Formularios e Instructivos de control interno.  </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Subsistemas de talento humano. </li>
                                            <li> <i class="far fa-circle text-purple"></i>  Capacitación gerencial y de equipo de trabajo.  </li>
                                        </ul>

                                        </div>
                                    </div>
                                </a>
                            </div>

                            <!-- Single Course Area -->
                            <div class="col-12 col-lg-4 wow fadeInUp" >
                                <a href="#">
                                    <div class="single-course-area d-flex mb-50">
                                        <div class="course-icon">
                                            
                                            <img src="<?php echo e(asset('public\images\default\servicios\marketing.jpg')); ?>" alt="" class="image-icon">

                                        </div>
                                        <div class="course-content" style="width:100%">
                                            <div class="text-center course-icon-mobile">
                                                <img src="<?php echo e(asset('public\images\default\servicios\marketing.jpg')); ?>" alt="" class="image-icon mb-4">
                                            </div>
                                            <h4 class="text-">Marketing </h4>

                                            <ul class="mt-2" style="font-weight:500;color:rgb(57, 57, 57)">
                                                <li> <i class="far fa-circle text-purple"></i> Imagen corporativa.  </li>
                                                <li> <i class="far fa-circle text-purple"></i> Creación de contenidos.  </li>
                                                <li> <i class="far fa-circle text-purple"></i> Edición de recursos fotográficos .  </li>
                                                <li> <i class="far fa-circle text-purple"></i> Capacitación posicionamiento redes sociales  . </li>

                                            </ul>

                                            </div>
                                        </div>
                                    </a>
                                </div>

                                <div class="col-12 col-lg-4 wow fadeInUp" >
                                    <a href="#">
                                        <div class="single-course-area d-flex mb-50">
                                            <div class="course-icon">
                                                
                                                <img src="<?php echo e(asset('public\images\default\servicios\sitio web.png')); ?>" alt="" class="image-icon">

                                            </div>
                                            <div class="course-content">
                                                <div class="text-center course-icon-mobile">
                                                    <img src="<?php echo e(asset('public\images\default\servicios\sitio web.png')); ?>" alt="" class="image-icon mb-4">
                                                </div>
                                                <h4 class="text-"> Sitios web </h4>
                                                <ul class="mt-2" style="font-weight:500;color:rgb(57, 57, 57)">
                                                    <li> <i class="far fa-circle text-purple"></i> Diseño y desarrollo de sitios web.  </li>
                                                    <li> <i class="far fa-circle text-purple"></i> Desarrollo de aplicaciones y otros.  </li>

                                                </ul>
                                                
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <!-- Single Course Area -->
                                <!-- Single Course Area -->
                                <div class="col-12 wow fadeInUp mt-4" >

                                    <div class="single-course-area d-flex mb-50 text-center">

                                        <div class="course-content text-center m-auto">
                                            <h4>Nuestro <span class="text-purple text-center">Plus</span> Empresarial:</h4>

                                            <p class="text-center">Te damos <span class="text-purple">acompañamiento</span> hasta que <span class="text-purple"> tu negocio esté en marcha. </span> </p>

                                        </div>
                                    </div>

                                </div>

                                    </div>
                                </div>
                            </div>
                                    <!-- ##### Course Area End ##### -->
                    <div style="background-image:url('public/images/default/home/porque.png')" class="paralax">
                        <div class="filter" style="background:rgba(27, 27, 27, 0.14)">
                            <div class="container garantia">
                                <div class="row">
                                    <div class="col-12">

                                        <h2 class="text-white my-5 text-center wow fadeInUp">¿Por Qué Escogernos?</h2>

                                        <ul style="text-align:center" class="text-white wow fadeInLeft">
                                            <li><i class="fas fa-check"></i> Cientos de testimonios de clientes satisfechos en nuestro sitio web y redes sociales.</li>
                                            <li><i class="fas fa-check"></i> Equipo multidisciplinario altamente calificado, con amplia y sólida experiencia. </li>
                                            <li><i class="fas fa-check"></i> Honradez intelectual.</li>
                                            <li><i class="fas fa-check"></i> Antiplagio.</li>
                                            <li><i class="fas fa-check"></i> Trabajos garantizados.</li>
                                            <li><i class="fas fa-check"></i> Cumplimiento de las normas establecidas por la casa de estudios.</li>
                                            <li><i class="fas fa-check"></i> Tiempos de respuestas oportunos.</li>
                                            <li><i class="fas fa-check"></i> Responsabilidad.</li>
                                            <li><i class="fas fa-check"></i> Compromiso.</li>


                                            <li><i class="fas fa-check"></i> Asesoría constante.</li>
                                            <li><i class="fas fa-check"></i> Nuestro Compromiso: garantizar tu éxito y sumar clientes satisfechos. </li>
                                        </ul>
                                        <br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div style="background-image:url('public/images/default/libros.jpg')" class="paralax articlesD">
                        <div class="filter" style="background:rgba(255, 245, 245, 0.71)">
                            <div class="container2">
                                <div class="row">
                                    <div class="col-12 text-center">
                                        <h2 class="text-purple my-5"><span></span> <i class="fas fa-book-open "></i> Artículos de interés</h2>
                                    </div>
                                </div>

                                
                                <br>
                            </div>

                        </div>
                    </div>

                    <div style="background-image:url('public/images/default/home/manosOk.jpg')" class="paralax">
                        <div class="filter" style="background:rgba(27, 27, 27, 0.48)">
                            <div class="container2">
                                <br>

                                <div class="card">

                                    <div class="card-body">
                                        <br>
                                        <h2 class="text-purple text-center"><span></span> <i class="fas fa-users"></i>Testimonios</h2>
                                        <br>
                                        <h5 class="text-center text-success">¿Ya has disfrutado de nuestros servicios? Por favor déjanos saber tu opinión acerca de nosotros.</h5>
                                        <br>
                                        <div class="">

                                            <div class="containerScroll bg-white border-g" style="overflow-y:auto;height:500px;border-radius:10px;">
                                                <div class="fb-comments" data-order-by="reverse_time" data-href="https://2vsoluciones.com/2v/" data-numposts="5" data-width="100%" style="padding-left:30px;padding-right:30px"></div>

                                            </div>
                                        </div>
                                        <br>

                                        <h5 class="text-center text-dark">Para ver mas comentarios ingresa a nuestra cuenta de facebook.</h5>
                                        <div class="text-center">
                                            <a target="_blank" href="https://business.facebook.com/me.quiero.graduar.ya/?business_id=301312427099496"><img src="<?php echo e(asset('public\images\default\redes sociales\logo-facebook.jpg')); ?>" alt="" style="border-radius:12px;max-width:50px !important">
                                            <p class="text-dark">ClicK Aqui</p></a>
                                        </div>

                                    </div>
                                </div>
                                <br>
                            </div>


                        </div>
                    </div>

                    <div class="paralax contacto py-5 text-center">
                        <div class="container2">
                            <img src="<?php echo e(asset('public\images\default\logo.jpg')); ?>" alt="" style="width:300px;margin:auto">
                            <h1 class="text-center text-purple wow fadeInUp mt-2"><span style="">¡Tu logro es nuestro éxito!</span></h1>
                        </div>
                    </div>



                    <div id="fb-root"></div>
                    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v7.0&appId=201064434390930&autoLogAppEvents=1" nonce="EAUQffoA"></script>

                    <!-- ##### Top Popular Courses Area End ##### -->
                    <?php echo $__env->make('front.home.modal.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2v\resources\views/front/home/index.blade.php ENDPATH**/ ?>