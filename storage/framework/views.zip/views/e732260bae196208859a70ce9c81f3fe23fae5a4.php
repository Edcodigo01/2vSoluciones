
<?php $__env->startSection('title'); ?>
  2V-Admin-categorías
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>


    <div class="row">
        <div class="col-12">
            
            <h2 class="mb-4 text-">Categorías de Artículos</h2>
        </div>
    </div>

    <table class="listar table table-bordered table-striped listar" data-route="list_admincategories" data-update="administrar-categorias/{id}" data-delete="administrar-categorias/{id}" id="table-categories" data-routeDisable="disabledCategory/{id}"  data-routeEnable="enabledCategory/{id}" data-delete="<?php echo e(url('administrar-categorias/{id}')); ?>">

    <thead>
      <tr>
        <th>Id</th>
        <th>Acciones:</th>
        <th>Nombre</th>
      </tr>
    </thead>
    <tbody>

    </tbody>
    </table>

    <?php echo $__env->make('category.includes.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.includes.modalEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.includes.modalDelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.includes.modalDisabled', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.includes.modalEnable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <input type="hidden" name="" value="<?php echo e($dataCategories); ?>" id="data">
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layoutsAdmin.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/vsolucio/public_html/2v-soluciones.com/2vR/resources/views/category/category.blade.php ENDPATH**/ ?>