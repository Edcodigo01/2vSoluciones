<!DOCTYPE html>
<html lang="es" style="position:relative">
<head>
   <?php echo $__env->make("front.layouts.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent("styles"); ?>
   <link rel="stylesheet" href="<?php echo e(asset("public\libraries\animate.css")); ?>">
</head>
<body>
   <div class="bg-lock"></div>

      <?php echo $__env->make("front.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php if(!strpos(request()->url(),'inicio-de-sesion')): ?>
          <?php echo $__env->make("front.layouts.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->make("front.layouts.fixedSocial", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      
      <div class="bg-" style="min-height:80%;">
          <?php echo $__env->yieldContent("content"); ?>
      </div>
      <?php if(!strpos(request()->url(),'inicio-de-sesion')): ?>
      <?php echo $__env->make("front.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>

      <?php echo $__env->make("front.layouts.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <input type="hidden" name="" value="<?php echo e(url('/')); ?>" id="url_base">

      <?php echo $__env->yieldContent("scripts"); ?>
      <script src="<?php echo e(asset("public\libraries\wow.js")); ?>"></script>
      <script type="text/javascript">
      $(document).ready(function() {
          wow = new WOW(
              {
                  animateClass: 'animated',
                  offset:       100,
                  callback:     function(box) {
                      console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
                  }
              }
          );
          wow.init();
      });
      </script>
      <div id="loader">
          <div class="loader-background">
          </div>
          <div class="loader loader-1">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>
          </div>
      </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\2vR\resources\views/front/layouts/index.blade.php ENDPATH**/ ?>